-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : venus
-- 
-- Part : #1
-- Date : 2016-12-05 13:46:17
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `filter_menu`
-- -----------------------------
DROP TABLE IF EXISTS `filter_menu`;
CREATE TABLE `filter_menu` (
  `type` varchar(100) NOT NULL,
  `menu` varchar(100) NOT NULL,
  `value` varchar(100) DEFAULT NULL,
  `ord` int(11) DEFAULT NULL,
  PRIMARY KEY (`type`,`menu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `filter_menu`
-- -----------------------------
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '一年内到期的非流动负债', '一年内到期的非流动负债', '83');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '偿还债务支付现金', '偿还债务支付现金', '64');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '其中子公司吸收现金', '其中子公司吸收现金', '85');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '其中子公司支付股利', '其中子公司支付股利', '89');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '其中：联营企业和合营企业的投资收益', '其中：联营企业和合营企业的投资收益', '84');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '其他应付款', '其他应付款', '41');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '其他应收款', '其他应收款', '34');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '其他流动负债', '其他流动负债', '90');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '其他流动资产', '其他流动资产', '67');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '其他综合收益', '其他综合收益', '91');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '其他非流动负债', '其他非流动负债', '79');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '净利润', '净利润', '5');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '分配股利、利润或偿付利息支付的现金', '分配股利、利润或偿付利息支付的现金', '32');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '利润总额', '利润总额', '3');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '取得借款的现金', '取得借款的现金', '65');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '取得子公司现金净额', '取得子公司现金净额', '87');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '可供出售金融资产', '可供出售金融资产', '86');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '吸收投资收到现金', '吸收投资收到现金', '60');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '固定资产', '固定资产', '16');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '在建工程', '在建工程', '63');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '处置固定资产、无形资产的现金', '处置固定资产、无形资产的现金', '54');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '存货', '存货', '56');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '少数股东权益', '少数股东权益', '72');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '应交税费', '应交税费', '28');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '应付利息', '应付利息', '81');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '应付票据', '应付票据', '75');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '应付股利', '应付股利', '80');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '应付账款', '应付账款', '37');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '应收票据', '应收票据', '69');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '应收账款', '应收账款', '42');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '归属于少数股东的综合收益总额', '归属于少数股东的综合收益总额', '74');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '归属于母公司股东权益合计', '归属于母公司股东权益合计', '27');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '归属于母公司股东的综合收益总额', '归属于母公司股东的综合收益总额', '55');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '所得税', '所得税', '22');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '扣非净利润', '扣非净利润', '7');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '投资支付的现金', '投资支付的现金', '68');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '投资收益', '投资收益', '62');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '投资现金流入', '投资现金流入', '21');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '投资现金流出', '投资现金流出', '13');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '投资现金流量净额', '投资现金流量净额', '19');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '支付其他与投资的现金', '支付其他与投资的现金', '76');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '支付其他与筹资的现金', '支付其他与筹资的现金', '61');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '支付的各项税费', '支付的各项税费', '18');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '支付给职工以及为职工支付的现金', '支付给职工以及为职工支付的现金', '4');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '收到其他与筹资的现金', '收到其他与筹资的现金', '73');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '收到的税费与返还', '收到的税费与返还', '70');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '无形资产', '无形资产', '24');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '未分配利润', '未分配利润', '17');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '汇率变动对现金的影响', '汇率变动对现金的影响', '82');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '流动负债合计', '流动负债合计', '43');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '流动资产合计', '流动资产合计', '35');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '现金及现金等价物净增加额', '现金及现金等价物净增加额', '9');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '盈余公积金', '盈余公积金', '26');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '短期借款', '短期借款', '66');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '筹资现金流入', '筹资现金流入', '15');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '筹资现金流出', '筹资现金流出', '2');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '筹资现金流量净额', '筹资现金流量净额', '8');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '管理费用', '管理费用', '48');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '经营现金流入', '经营现金流入', '20');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '经营现金流出', '经营现金流出', '6');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '经营现金流量净额', '经营现金流量净额', '11');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '综合收益总额', '综合收益总额', '50');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '股东权益合计', '股东权益合计', '1');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '股本', '股本', '30');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '营业利润', '营业利润', '12');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '营业外支出', '营业外支出', '51');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '营业外收入', '营业外收入', '45');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '营业总成本', '营业总成本', '10');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '营业总收入', '营业总收入', '14');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '营业成本', '营业成本', '44');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '营业收入', '营业收入', '46');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '营业税金及附加', '营业税金及附加', '53');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '负债合计', '负债合计', '29');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '负债和股东权益总计', '负债和股东权益总计', '39');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '财务费用', '财务费用', '49');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '货币资金', '货币资金', '25');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '购建固定资产和其他支付的现金', '购建固定资产和其他支付的现金', '36');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '资产减值损失', '资产减值损失', '23');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '资产总计', '资产总计', '31');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '资本公积金', '资本公积金', '38');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '递延所得税负债', '递延所得税负债', '88');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '递延所得税资产', '递延所得税资产', '57');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '销售商品、提供劳务收到的现金', '销售商品、提供劳务收到的现金', '40');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '销售费用', '销售费用', '59');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '长期借款', '长期借款', '78');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '长期待摊费用', '长期待摊费用', '71');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '长期股权投资', '长期股权投资', '77');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '非流动负债合计', '非流动负债合计', '58');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '非流动资产合计', '非流动资产合计', '33');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '预付账款', '预付账款', '47');
INSERT INTO `filter_menu` VALUES ('financerateStockFilter', '预收账款', '预收账款', '52');
INSERT INTO `filter_menu` VALUES ('hangyeStockFilter', '一级分类', '1', '1');
INSERT INTO `filter_menu` VALUES ('hangyeStockFilter', '三级分类', '3', '3');
INSERT INTO `filter_menu` VALUES ('hangyeStockFilter', '二级分类', '2', '2');
INSERT INTO `filter_menu` VALUES ('xianjinliuStockFilter', '投资现金', '投资现金', '3');
INSERT INTO `filter_menu` VALUES ('xianjinliuStockFilter', '筹资现金', '筹资现金', '1');
INSERT INTO `filter_menu` VALUES ('xianjinliuStockFilter', '经营现金', '经营现金', '2');

-- -----------------------------
-- Table structure for `lu_strategy`
-- -----------------------------
DROP TABLE IF EXISTS `lu_strategy`;
CREATE TABLE `lu_strategy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `attr` varchar(255) DEFAULT NULL,
  `rate_3month` decimal(20,4) DEFAULT NULL,
  `rate_1month` decimal(20,4) DEFAULT NULL,
  `update_time` varchar(20) DEFAULT NULL,
  `strategy_class` varchar(100) DEFAULT NULL,
  `up` int(11) DEFAULT NULL,
  `down` int(11) DEFAULT NULL,
  `flat` int(11) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `modify_date` varchar(20) DEFAULT NULL,
  `interval_day` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `run_status` int(11) NOT NULL DEFAULT '1' COMMENT '1,已经运行过，0没有运行过',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `lu_strategy`
-- -----------------------------
INSERT INTO `lu_strategy` VALUES ('1', '稳定增长', '业绩长期稳定增长，上市日期超过8年的股票，营业收入、净利润持续增加。', '0.0000', '0.0000', '20161202195143', '', '8', '16', '0', '2', 'JISHU', '2016-12-02', '0', '1', '1');
INSERT INTO `lu_strategy` VALUES ('2', '筹资投资增长', '面向未来，筹资投资活动增加的股票。', '0.0000', '0.0000', '20161201172222', 'luChoose2', '3', '7', '1', '3', 'JISHU', '2016-12-01', '30', '0', '1');
INSERT INTO `lu_strategy` VALUES ('3', '测试', '精选价值被低估的股票', '0.0000', '0.0000', '20161108023411', 'luChoose3', '10', '14', '1', './img/index_top_1.jpg', 'JISHU', '2016-11-08', '30', '0', '1');
INSERT INTO `lu_strategy` VALUES ('4', '测试2', '精选价值被低估的股票', '0.0000', '0.0000', '20161113024256', 'luChoose4', '0', '0', '0', './img/index_top_1.jpg', 'JISHU', '2016-11-13', '30', '0', '1');

-- -----------------------------
-- Table structure for `lu_strategy_change_rate`
-- -----------------------------
DROP TABLE IF EXISTS `lu_strategy_change_rate`;
CREATE TABLE `lu_strategy_change_rate` (
  `id` int(11) NOT NULL,
  `dt` varchar(20) NOT NULL,
  `day7_change_rate` decimal(20,2) DEFAULT NULL,
  `day14_change_rate` decimal(20,2) DEFAULT NULL,
  `day21_change_rate` decimal(20,2) DEFAULT NULL,
  `month1_change_rate` decimal(20,2) DEFAULT NULL,
  `month3_change_rate` decimal(20,2) DEFAULT NULL,
  `month6_change_rate` decimal(20,2) DEFAULT NULL,
  `year1_change_rate` decimal(20,2) DEFAULT NULL,
  `year2_change_rate` decimal(20,2) DEFAULT NULL,
  `year3_change_rate` decimal(20,2) DEFAULT NULL,
  `year4_change_rate` decimal(20,2) DEFAULT NULL,
  `year5_change_rate` decimal(20,2) DEFAULT NULL,
  `year6_change_rate` decimal(20,2) DEFAULT NULL,
  `year7_change_rate` decimal(20,2) DEFAULT NULL,
  `year8_change_rate` decimal(20,2) DEFAULT NULL,
  `year9_change_rate` decimal(20,2) DEFAULT NULL,
  `year10_change_rate` decimal(20,2) DEFAULT NULL,
  PRIMARY KEY (`id`,`dt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `lu_strategy_change_rate`
-- -----------------------------
INSERT INTO `lu_strategy_change_rate` VALUES ('-1', '2016-12-02', '0.00', '-3.15', '-0.20', '0.89', '-9.33', '-20.27', '14.38', '78.69', '298.19', '445.96', '470.09', '362.71', '335.89', '879.23', '429.13', '526.67');
INSERT INTO `lu_strategy_change_rate` VALUES ('1', '2016-11-14', '-2.19', '-2.82', '-1.86', '-3.76', '-1.54', '-11.81', '8.87', '-32.90', '-45.92', '-56.37', '-28.47', '-8.23', '5.39', '-72.61', '31.50', '-119.59');
INSERT INTO `lu_strategy_change_rate` VALUES ('1', '2016-11-15', '-1.06', '-1.99', '-2.33', '-3.76', '-2.89', '2.70', '6.98', '40.19', '92.04', '267.34', '204.03', '190.13', '387.24', '986.44', '352.41', '1019.46');
INSERT INTO `lu_strategy_change_rate` VALUES ('1', '2016-11-16', '-0.16', '-1.48', '-1.62', '-3.57', '-2.55', '1.73', '8.86', '41.07', '93.24', '273.30', '212.46', '198.16', '383.27', '1055.49', '353.66', '1063.01');
INSERT INTO `lu_strategy_change_rate` VALUES ('1', '2016-11-17', '-0.82', '-1.05', '-2.17', '-3.76', '-3.44', '1.44', '9.21', '39.96', '93.98', '277.08', '218.39', '187.42', '377.79', '990.75', '358.37', '1064.91');
INSERT INTO `lu_strategy_change_rate` VALUES ('1', '2016-11-19', '-0.01', '-1.89', '-2.32', '-2.98', '-2.42', '-10.70', '9.46', '-34.70', '-40.93', '-57.86', '-30.95', '-7.74', '5.88', '-77.92', '28.39', '-110.43');
INSERT INTO `lu_strategy_change_rate` VALUES ('1', '2016-11-21', '0.52', '-0.25', '-0.96', '-1.86', '-2.14', '0.11', '6.43', '44.03', '111.14', '319.33', '232.77', '241.05', '244.09', '799.72', '309.14', '1035.23');
INSERT INTO `lu_strategy_change_rate` VALUES ('1', '2016-11-22', '-0.43', '-1.26', '-2.27', '-2.41', '-4.04', '-0.32', '6.14', '38.02', '88.87', '248.26', '217.39', '172.15', '358.19', '1064.90', '357.71', '1042.35');
INSERT INTO `lu_strategy_change_rate` VALUES ('1', '2016-11-24', '-1.01', '-2.32', '-2.55', '-3.92', '-6.28', '-1.85', '1.94', '42.02', '96.96', '281.30', '218.66', '183.04', '357.22', '1070.97', '366.54', '1003.32');
INSERT INTO `lu_strategy_change_rate` VALUES ('1', '2016-11-25', '-1.59', '-1.52', '-2.70', '-3.49', '-6.28', '-1.07', '2.31', '42.45', '96.35', '281.30', '216.96', '183.04', '356.27', '1070.70', '362.06', '989.11');
INSERT INTO `lu_strategy_change_rate` VALUES ('1', '2016-11-29', '-0.82', '-0.46', '-0.09', '0.55', '-1.36', '-0.52', '-1.11', '25.41', '52.90', '175.33', '121.33', '38.01', '2.42', '-86.39', '27.20', '-100.94');
INSERT INTO `lu_strategy_change_rate` VALUES ('1', '2016-12-01', '0.00', '0.90', '-0.56', '-0.26', '-0.15', '-0.29', '5.22', '21.94', '61.56', '172.79', '117.32', '45.26', '18.38', '107.82', '21.50', '105.76');
INSERT INTO `lu_strategy_change_rate` VALUES ('1', '2016-12-02', '0.00', '-0.54', '-0.31', '-0.20', '-0.15', '-0.71', '2.91', '22.73', '60.12', '172.79', '124.26', '45.26', '13.63', '100.54', '21.30', '111.88');
INSERT INTO `lu_strategy_change_rate` VALUES ('2', '2016-11-15', '-1.74', '-2.11', '-1.85', '-4.64', '-1.68', '-12.00', '8.88', '-33.61', '-45.91', '-57.53', '-28.84', '-10.50', '5.47', '-72.60', '31.33', '-119.57');
INSERT INTO `lu_strategy_change_rate` VALUES ('2', '2016-11-16', '1.52', '1.44', '1.33', '1.10', '3.43', '10.81', '5.20', '32.04', '108.00', '184.08', '114.05', '102.41', '121.38', '371.35', '148.89', '382.53');
INSERT INTO `lu_strategy_change_rate` VALUES ('2', '2016-11-17', '0.28', '1.25', '0.96', '0.46', '2.92', '10.58', '6.28', '30.94', '110.95', '186.15', '115.91', '99.12', '118.16', '349.02', '141.33', '375.90');
INSERT INTO `lu_strategy_change_rate` VALUES ('2', '2016-11-19', '-0.01', '-1.89', '-2.32', '-2.98', '-2.42', '-10.70', '9.46', '-34.70', '-40.93', '-57.86', '-30.95', '-7.74', '5.88', '-77.92', '28.39', '-110.43');
INSERT INTO `lu_strategy_change_rate` VALUES ('2', '2016-11-21', '0.62', '1.33', '2.10', '1.49', '5.01', '11.84', '0.64', '15.16', '72.35', '161.72', '89.93', '68.81', '78.89', '303.52', '138.29', '282.32');
INSERT INTO `lu_strategy_change_rate` VALUES ('2', '2016-11-22', '-0.49', '0.42', '1.26', '1.05', '3.11', '9.52', '4.66', '30.29', '103.76', '164.93', '102.65', '86.08', '123.34', '374.28', '159.07', '381.50');
INSERT INTO `lu_strategy_change_rate` VALUES ('2', '2016-11-24', '-0.29', '-0.42', '0.41', '0.00', '2.90', '8.82', '0.42', '31.53', '105.15', '193.14', '117.04', '89.12', '115.47', '347.59', '152.27', '369.12');
INSERT INTO `lu_strategy_change_rate` VALUES ('2', '2016-11-25', '-0.36', '-0.50', '0.17', '0.03', '2.90', '9.55', '-0.45', '32.22', '104.79', '193.14', '118.21', '89.12', '119.15', '341.67', '151.55', '365.10');
INSERT INTO `lu_strategy_change_rate` VALUES ('2', '2016-12-01', '0.00', '0.39', '-1.25', '0.35', '-0.50', '5.63', '5.92', '85.29', '166.37', '442.16', '252.12', '186.67', '172.71', '496.65', '194.72', '658.50');
INSERT INTO `lu_strategy_change_rate` VALUES ('4', '2016-11-08', '-0.36', '-0.11', '-1.50', '-2.35', '-3.94', '-9.09', '12.22', '-31.39', '-46.07', '-50.43', '-24.88', '3.66', '3.79', '-87.11', '32.28', '-124.13');
INSERT INTO `lu_strategy_change_rate` VALUES ('4', '2016-11-09', '-1.16', '-0.74', '-2.09', '-0.64', '3.15', '4.04', '15.35', '20.06', '83.21', '132.64', '94.04', '80.39', '150.66', '335.53', '190.06', '382.20');
INSERT INTO `lu_strategy_change_rate` VALUES ('4', '2016-11-10', '-0.76', '-1.34', '-2.17', '-2.54', '-2.93', '-10.27', '11.56', '-32.52', '-46.41', '-50.57', '-25.81', '-3.00', '3.13', '-88.18', '31.35', '-129.75');
INSERT INTO `lu_strategy_change_rate` VALUES ('4', '2016-11-13', '-1.81', '-2.43', '-1.47', '-3.37', '-0.70', '-10.73', '8.78', '-32.39', '-48.28', '-53.71', '-24.50', '-3.09', '5.75', '-75.81', '31.76', '-122.87');
INSERT INTO `lu_strategy_change_rate` VALUES ('6', '2016-12-01', '0.00', '-1.47', '-5.09', '-21.80', '17.52', '18.25', '13.40', '-18.84', '-43.66', '-64.77', '-35.87', '-10.02', '3.23', '-77.95', '28.05', '-95.13');
INSERT INTO `lu_strategy_change_rate` VALUES ('6', '2016-12-02', '0.00', '-3.42', '-10.38', '-16.96', '17.47', '41.31', '39.61', '94.77', '150.74', '229.16', '124.89', '100.14', '123.60', '403.31', '177.07', '493.96');
INSERT INTO `lu_strategy_change_rate` VALUES ('13', '2016-12-02', '0.00', '3.41', '5.43', '22.39', '15.39', '34.25', '14.20', '99.98', '152.76', '44.60', '68.16', '126.97', '184.29', '251.19', '194.77', '501.93');
INSERT INTO `lu_strategy_change_rate` VALUES ('14', '2016-12-02', '0.00', '8.98', '8.26', '8.48', '15.19', '23.67', '52.31', '99.98', '152.76', '44.60', '68.16', '126.97', '184.29', '251.19', '194.77', '501.93');
INSERT INTO `lu_strategy_change_rate` VALUES ('16', '2016-12-02', '0.00', '4.00', '3.59', '1.90', '2.44', '6.50', '52.31', '99.98', '152.76', '44.60', '68.16', '126.97', '184.29', '251.19', '194.77', '501.93');

-- -----------------------------
-- Table structure for `lu_strategy_filter`
-- -----------------------------
DROP TABLE IF EXISTS `lu_strategy_filter`;
CREATE TABLE `lu_strategy_filter` (
  `id` int(11) NOT NULL,
  `filter` varchar(100) DEFAULT NULL,
  `condition` varchar(255) DEFAULT NULL,
  `update_time` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `lu_strategy_filter`
-- -----------------------------
INSERT INTO `lu_strategy_filter` VALUES ('2', 'jingzichanshouyilvStockFilter', '>1', '');
INSERT INTO `lu_strategy_filter` VALUES ('2', 'xianjinliuStockFilter', '投资现金,>30', '');
INSERT INTO `lu_strategy_filter` VALUES ('2', 'xianjinliuStockFilter', '筹资现金,>30', '');
INSERT INTO `lu_strategy_filter` VALUES ('2', 'financerateStockFilter', '股东权益合计,>100', '');
INSERT INTO `lu_strategy_filter` VALUES ('2', 'codeStockFilter', 'IN000001', '');
INSERT INTO `lu_strategy_filter` VALUES ('6', 'xiadieStockFilter', '30,<-15', '');
INSERT INTO `lu_strategy_filter` VALUES ('6', 'hangyeStockFilter', '1,!=房地产&&!=金融服务&&!=信息服务', '');
INSERT INTO `lu_strategy_filter` VALUES ('6', 'codeStockFilter', '000001', '');
INSERT INTO `lu_strategy_filter` VALUES ('8', 'dongshizhangStockFilter', '', '');
INSERT INTO `lu_strategy_filter` VALUES ('8', 'jingzichanshouyilvStockFilter', '>50', '');
INSERT INTO `lu_strategy_filter` VALUES ('8', 'shangshiriqiStockFilter', '>10', '');
INSERT INTO `lu_strategy_filter` VALUES ('9', 'dongshizhangStockFilter', '', '');
INSERT INTO `lu_strategy_filter` VALUES ('9', 'jingzichanshouyilvStockFilter', '>50', '');
INSERT INTO `lu_strategy_filter` VALUES ('10', 'dongshizhangStockFilter', '', '');
INSERT INTO `lu_strategy_filter` VALUES ('10', 'jingzichanshouyilvStockFilter', '>50', '');
INSERT INTO `lu_strategy_filter` VALUES ('11', 'dongshizhangStockFilter', '', '');
INSERT INTO `lu_strategy_filter` VALUES ('11', 'jingzichanshouyilvStockFilter', '>50', '');
INSERT INTO `lu_strategy_filter` VALUES ('12', 'dongshizhangStockFilter', '', '');
INSERT INTO `lu_strategy_filter` VALUES ('12', 'jingzichanshouyilvStockFilter', '>50', '');
INSERT INTO `lu_strategy_filter` VALUES ('13', 'priceStockFilter', '>100', '');
INSERT INTO `lu_strategy_filter` VALUES ('14', 'priceStockFilter', '>150', '');
INSERT INTO `lu_strategy_filter` VALUES ('15', 'priceStockFilter', '>180', '');
INSERT INTO `lu_strategy_filter` VALUES ('16', 'priceStockFilter', '>180', '');
INSERT INTO `lu_strategy_filter` VALUES ('1', 'zongshizhiStockFilter', '<100', '');
INSERT INTO `lu_strategy_filter` VALUES ('1', 'shiyinglvttmStockFilter', '<60', '');
INSERT INTO `lu_strategy_filter` VALUES ('1', 'jingzichanshouyilvStockFilter', '>5', '');
INSERT INTO `lu_strategy_filter` VALUES ('1', 'top1holderrateStockFilter', '>20', '');
INSERT INTO `lu_strategy_filter` VALUES ('1', 'xiaoshoumaolilvStockFilter', '>20', '');
INSERT INTO `lu_strategy_filter` VALUES ('1', 'zichanfuzhailvStockFilter', '<80', '');
INSERT INTO `lu_strategy_filter` VALUES ('1', 'jinglirunstableStockFilter', '', '');
INSERT INTO `lu_strategy_filter` VALUES ('1', 'shangshiriqiStockFilter', '>8', '');
INSERT INTO `lu_strategy_filter` VALUES ('1', 'nameStockFilter', '!IN恒宝股份', '');
INSERT INTO `lu_strategy_filter` VALUES ('1', 'codeStockFilter', '000001', '');

-- -----------------------------
-- Table structure for `lu_strategy_stock`
-- -----------------------------
DROP TABLE IF EXISTS `lu_strategy_stock`;
CREATE TABLE `lu_strategy_stock` (
  `id` int(11) NOT NULL,
  `code` varchar(20) NOT NULL,
  `market` varchar(20) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `addtime` varchar(20) DEFAULT NULL,
  `quittime` varchar(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `score` int(11) NOT NULL DEFAULT '0',
  `change_rate` decimal(20,2) DEFAULT NULL,
  `curr_price` decimal(20,2) DEFAULT NULL,
  `zongshizhi` decimal(20,2) DEFAULT NULL,
  `shiyinglvttm` decimal(20,2) DEFAULT NULL,
  `update_time` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `lu_strategy_stock`
-- -----------------------------
INSERT INTO `lu_strategy_stock` VALUES ('-1', '000018', 'SZ', '神州长城', '2016-12-02 19:08:19', '', '1', '2', '0.68', '10.35', '17576835863.85', '32.17', '20161202190819');
INSERT INTO `lu_strategy_stock` VALUES ('-1', '002714', 'SZ', '牧原股份', '2016-12-02 19:08:20', '', '1', '2', '-0.24', '24.87', '25709268441.66', '12.37', '20161202190820');
INSERT INTO `lu_strategy_stock` VALUES ('1', '000001', 'SZ', '平安银行', '2016-12-01 14:45:05', '', '1', '6', '0.96', '9.45', '162260387408.70', '7.10', '20161202195142');
INSERT INTO `lu_strategy_stock` VALUES ('1', '002104', 'SZ', '恒宝股份', '2016-11-29 12:22:19', '', '0', '0', '-1.13', '13.99', '9983935520.00', '43.79', '20161129142628');
INSERT INTO `lu_strategy_stock` VALUES ('1', '002179', 'SZ', '中航光电', '2016-10-31 04:00:23', '', '0', '0', '0.49', '37.26', '22449704577.84', '31.69', '20161125142359');
INSERT INTO `lu_strategy_stock` VALUES ('1', '002236', 'SZ', '大华股份', '2016-10-31 04:00:23', '', '0', '0', '-0.71', '14.00', '40591759670.00', '24.15', '20161125142359');
INSERT INTO `lu_strategy_stock` VALUES ('1', '002262', 'SZ', '恩华药业', '2016-11-15 10:10:31', '', '0', '0', '0.88', '19.46', '12273750523.72', '41.38', '20161125142359');
INSERT INTO `lu_strategy_stock` VALUES ('1', '002271', 'SZ', '东方雨虹', '2016-11-15 10:10:31', '', '0', '0', '-0.45', '22.21', '19604474894.08', '21.77', '20161125142359');
INSERT INTO `lu_strategy_stock` VALUES ('1', '002294', 'SZ', '信立泰', '2016-11-15 10:10:31', '', '0', '0', '-0.47', '29.75', '31118976000.00', '22.56', '20161125142359');
INSERT INTO `lu_strategy_stock` VALUES ('1', '002317', 'SZ', '众生药业', '2016-11-15 10:10:31', '', '0', '0', '0.08', '13.30', '10838290710.80', '28.93', '20161125142359');
INSERT INTO `lu_strategy_stock` VALUES ('1', '002327', 'SZ', '富安娜', '2016-11-29 12:22:19', '', '1', '6', '-0.22', '9.28', '7904405081.92', '25.41', '20161202195142');
INSERT INTO `lu_strategy_stock` VALUES ('1', '002367', 'SZ', '康力电梯', '2016-10-31 04:00:24', '', '0', '0', '-0.27', '14.69', '11717517972.03', '22.29', '20161125142359');
INSERT INTO `lu_strategy_stock` VALUES ('1', '002372', 'SZ', '伟星新材', '2016-10-31 04:00:24', '', '0', '0', '-0.25', '16.26', '12612828992.40', '21.63', '20161125142359');
INSERT INTO `lu_strategy_stock` VALUES ('1', '002518', 'SZ', '科士达', '2016-10-31 04:00:24', '', '1', '6', '1.48', '22.00', '9797070360.00', '35.09', '20161202195142');
INSERT INTO `lu_strategy_stock` VALUES ('1', '002542', 'SZ', '中化岩土', '2016-11-22 03:11:16', '', '0', '0', '-0.73', '8.21', '14346975000.00', '59.68', '20161125142359');
INSERT INTO `lu_strategy_stock` VALUES ('1', '002543', 'SZ', '万和电气', '2016-11-15 10:10:33', '', '1', '6', '0.73', '19.20', '8448000000.00', '23.69', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '002572', 'SZ', '索菲亚', '2016-11-15 10:10:33', '', '0', '0', '-0.75', '56.71', '26183753020.05', '44.27', '20161125142359');
INSERT INTO `lu_strategy_stock` VALUES ('1', '002666', 'SZ', '德联集团', '2016-11-29 12:22:19', '', '1', '6', '-1.46', '8.80', '6638097558.40', '45.41', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '002701', 'SZ', '奥瑞金', '2016-11-15 10:10:34', '', '0', '0', '0.53', '9.42', '22186225152.00', '19.14', '20161125142400');
INSERT INTO `lu_strategy_stock` VALUES ('1', '002717', 'SZ', '岭南园林', '2016-10-31 04:00:24', '', '0', '0', '-0.45', '28.76', '11765436078.92', '52.59', '20161125142400');
INSERT INTO `lu_strategy_stock` VALUES ('1', '002727', 'SZ', '一心堂', '2016-11-15 10:10:34', '', '0', '0', '-0.88', '22.41', '11666646000.00', '30.79', '20161125142400');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300026', 'SZ', '红日药业', '2016-11-15 10:10:35', '', '0', '0', '-1.73', '6.25', '18821227143.75', '32.33', '20161125142400');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300043', 'SZ', '星辉娱乐', '2016-11-15 10:10:35', '', '0', '0', '-1.12', '12.31', '15316082316.31', '34.48', '20161125142400');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300113', 'SZ', '顺网科技', '2016-11-04 11:11:44', '', '0', '0', '-0.73', '32.48', '22297612860.32', '46.78', '20161125142400');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300115', 'SZ', '长盈精密', '2016-11-15 10:10:36', '', '0', '0', '-1.13', '25.45', '22974333053.25', '37.29', '20161125142400');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300133', 'SZ', '华策影视', '2016-11-15 10:10:36', '', '0', '0', '-2.25', '13.46', '23509579512.66', '43.86', '20161125142400');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300144', 'SZ', '宋城演艺', '2016-11-15 10:10:36', '', '0', '0', '-4.77', '23.14', '33613478171.78', '39.31', '20161125142400');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300145', 'SZ', '中金环境', '2016-11-17 05:13:49', '', '0', '0', '-0.22', '27.31', '18239267742.48', '41.76', '20161125142400');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300172', 'SZ', '中电环保', '2016-11-15 10:10:36', '', '1', '6', '-1.74', '10.71', '5429970000.00', '47.91', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300182', 'SZ', '捷成股份', '2016-11-15 10:10:36', '', '0', '0', '0.00', '11.13', '28520264454.78', '37.28', '20161125142400');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300196', 'SZ', '长海股份', '2016-11-15 10:10:36', '', '1', '6', '-0.73', '40.88', '8676699793.44', '33.39', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300197', 'SZ', '铁汉生态', '2016-11-15 10:10:36', '', '0', '0', '0.95', '11.71', '17795143831.65', '52.20', '20161125142401');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300199', 'SZ', '翰宇药业', '2016-11-22 03:11:17', '', '0', '0', '-0.49', '20.43', '18761738092.20', '59.62', '20161125142401');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300251', 'SZ', '光线传媒', '2016-11-15 10:10:37', '', '0', '0', '0.09', '11.21', '32885750522.72', '48.26', '20161122031117');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300255', 'SZ', '常山药业', '2016-10-31 04:00:24', '', '1', '6', '-2.06', '9.05', '8461450245.90', '49.62', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300258', 'SZ', '精锻科技', '2016-10-31 04:00:24', '', '1', '6', '-1.67', '15.27', '6184350000.00', '36.29', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300267', 'SZ', '尔康制药', '2016-11-15 10:10:37', '', '0', '0', '-1.24', '14.37', '29607390645.18', '34.26', '20161125142401');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300271', 'SZ', '华宇软件', '2016-11-15 10:10:37', '', '0', '0', '-0.95', '19.78', '12719186430.18', '50.79', '20161125142401');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300284', 'SZ', '苏交科', '2016-11-15 10:10:37', '', '0', '0', '-0.83', '22.79', '12678788503.80', '36.05', '20161125142401');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300289', 'SZ', '利德曼', '2016-11-29 12:22:19', '', '1', '6', '0.21', '13.99', '5933022387.65', '47.24', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300296', 'SZ', '利亚德', '2016-11-01 11:35:20', '', '0', '0', '-2.41', '32.37', '26363918870.25', '58.62', '20161125142401');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300336', 'SZ', '新文化', '2016-11-15 10:10:38', '', '0', '0', '-1.46', '20.94', '11256256585.80', '42.09', '20161125142401');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300357', 'SZ', '我武生物', '2016-10-31 04:00:24', '', '1', '6', '-0.46', '40.96', '6619136000.00', '46.45', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300360', 'SZ', '炬华科技', '2016-11-17 05:13:49', '', '1', '6', '1.58', '21.88', '7935383700.00', '30.84', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300373', 'SZ', '扬杰科技', '2016-10-31 04:00:24', '', '0', '0', '1.93', '22.69', '10720817227.67', '58.18', '20161125142401');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300396', 'SZ', '迪瑞医疗', '2016-11-15 10:10:39', '', '0', '0', '-1.24', '45.49', '7063301000.00', '59.79', '20161117095438');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300403', 'SZ', '地尔汉宇', '2016-11-01 11:35:20', '', '1', '6', '0.19', '73.99', '9914660000.00', '52.39', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300408', 'SZ', '三环集团', '2016-11-15 10:10:39', '', '0', '0', '0.57', '17.56', '30350465570.32', '30.18', '20161125142401');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300432', 'SZ', '富临精工', '2016-11-15 10:10:39', '', '0', '0', '-4.09', '30.69', '11048400000.00', '53.55', '20161125142401');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300443', 'SZ', '金雷风电', '2016-11-29 12:22:19', '', '1', '6', '-2.15', '68.69', '8176060864.69', '46.92', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300446', 'SZ', '乐凯新材', '2016-11-29 12:22:20', '', '1', '6', '1.95', '44.35', '5446180000.00', '51.01', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300476', 'SZ', '胜宏科技', '2016-10-31 04:00:24', '', '1', '6', '-2.13', '23.85', '8917515000.00', '46.29', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '300497', 'SZ', '富祥股份', '2016-11-15 10:10:40', '', '1', '6', '-2.30', '78.06', '8745627735.00', '56.32', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '600066', 'SH', '宇通客车', '2016-11-15 10:10:41', '', '0', '0', '-0.88', '20.30', '44942966226.90', '14.06', '20161125142402');
INSERT INTO `lu_strategy_stock` VALUES ('1', '601000', 'SH', '唐山港', '2016-11-15 10:10:42', '', '0', '0', '0.23', '4.28', '17321969895.84', '13.04', '20161122031117');
INSERT INTO `lu_strategy_stock` VALUES ('1', '601199', 'SH', '江南水务', '2016-11-17 05:13:50', '', '1', '6', '-0.23', '8.65', '8089495604.60', '25.59', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '601222', 'SH', '林洋能源', '2016-11-01 11:35:20', '', '0', '0', '-0.22', '9.03', '15735062325.57', '31.39', '20161125142402');
INSERT INTO `lu_strategy_stock` VALUES ('1', '601567', 'SH', '三星医疗', '2016-11-15 10:10:43', '', '0', '0', '-1.07', '12.91', '18316797259.74', '36.93', '20161125142402');
INSERT INTO `lu_strategy_stock` VALUES ('1', '601689', 'SH', '拓普集团', '2016-11-15 10:10:43', '', '0', '0', '-1.06', '29.80', '19343180000.00', '38.37', '20161125142402');
INSERT INTO `lu_strategy_stock` VALUES ('1', '601799', 'SH', '星宇股份', '2016-10-31 04:00:24', '', '0', '0', '-1.33', '40.67', '11231233285.44', '33.76', '20161125142402');
INSERT INTO `lu_strategy_stock` VALUES ('1', '603020', 'SH', '爱普股份', '2016-11-29 12:22:20', '', '1', '6', '-1.74', '23.14', '7404800000.00', '39.41', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '603168', 'SH', '莎普爱思', '2016-11-29 12:22:20', '', '1', '6', '0.96', '46.18', '7544657500.00', '29.49', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '603199', 'SH', '九华旅游', '2016-11-29 12:22:20', '', '1', '6', '-0.66', '45.16', '4998308800.00', '58.25', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '603338', 'SH', '浙江鼎力', '2016-10-31 04:00:24', '', '1', '6', '-2.87', '52.06', '8459750000.00', '49.29', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '603567', 'SH', '珍宝岛', '2016-10-31 04:00:24', '', '0', '0', '-2.12', '22.64', '19224982400.00', '44.25', '20161125142402');
INSERT INTO `lu_strategy_stock` VALUES ('1', '603686', 'SH', '龙马环卫', '2016-11-15 10:10:44', '', '1', '6', '-0.74', '34.69', '9447821500.00', '48.22', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '603788', 'SH', '宁波高发', '2016-11-15 10:10:44', '', '1', '6', '-0.75', '48.81', '6880745700.00', '48.45', '20161202195143');
INSERT INTO `lu_strategy_stock` VALUES ('1', '603866', 'SH', '桃李面包', '2016-11-15 10:10:44', '', '0', '0', '-1.93', '46.27', '20827330020.00', '49.28', '20161125142402');
INSERT INTO `lu_strategy_stock` VALUES ('1', '603883', 'SH', '老百姓', '2016-11-15 10:10:44', '', '0', '0', '-1.84', '52.95', '14137650000.00', '49.66', '20161125142402');
INSERT INTO `lu_strategy_stock` VALUES ('1', '603898', 'SH', '好莱客', '2016-11-15 10:10:44', '', '0', '0', '-0.26', '34.23', '10265577000.00', '48.98', '20161125142402');
INSERT INTO `lu_strategy_stock` VALUES ('1', '603899', 'SH', '晨光文具', '2016-11-15 10:10:44', '', '0', '0', '-1.31', '19.53', '17967600000.00', '36.48', '20161125142402');
INSERT INTO `lu_strategy_stock` VALUES ('1', '603939', 'SH', '益丰药房', '2016-11-15 10:10:44', '', '0', '0', '-0.06', '33.17', '12030581805.86', '57.28', '20161125142402');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000019', 'SZ', '深深宝Ａ', '2016-11-25 14:07:13', '', '0', '0', '-1.02', '18.40', '8309813078.40', '-202.14', '20161125141140');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000037', 'SZ', '*ST南电A', '2016-11-25 14:07:13', '', '0', '0', '0.34', '11.83', '7130681510.68', '-11.39', '20161125141140');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000066', 'SZ', '长城电脑', '2016-11-25 14:07:13', '', '0', '0', '10.02', '12.74', '16862586107.64', '-3730.66', '20161125141140');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000088', 'SZ', '盐 田 港', '2016-11-15 09:05:50', '', '0', '0', '0.39', '7.73', '15013206000.00', '30.97', '20161122031219');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000150', 'SZ', '宜华健康', '2016-11-15 09:05:51', '', '0', '0', '-0.21', '33.30', '14911902404.10', '15.43', '20161201164252');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000401', 'SZ', '冀东水泥', '2016-11-25 14:07:13', '', '0', '0', '-2.25', '11.32', '15253959386.48', '-12.17', '20161125141140');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000404', 'SZ', '华意压缩', '2016-11-15 09:21:29', '', '0', '0', '-1.12', '11.43', '6396501782.79', '29.44', '20161125142508');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000506', 'SZ', '中润资源', '2016-11-25 14:07:14', '', '0', '0', '-1.12', '8.80', '8175356296.80', '-282.20', '20161125141141');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000526', 'SZ', '紫光学大', '2016-11-25 14:07:14', '', '0', '0', '-0.42', '42.23', '4062319368.61', '-116.27', '20161125141141');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000528', 'SZ', '柳 工', '2016-11-25 14:07:14', '', '0', '0', '-0.98', '8.07', '9080704037.52', '1780.53', '20161125141141');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000534', 'SZ', '万泽股份', '2016-11-15 09:21:30', '', '0', '0', '-2.32', '16.02', '7878397237.92', '117.26', '20161125142508');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000537', 'SZ', '广宇发展', '2016-11-04 12:17:29', '', '0', '0', '0.82', '9.82', '5034886645.42', '18.96', '20161201164253');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000553', 'SZ', '沙隆达Ａ', '2016-11-25 14:07:14', '', '0', '0', '-2.45', '16.34', '9704705414.80', '638.05', '20161125141141');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000554', 'SZ', '泰山石油', '2016-11-25 14:07:15', '', '0', '0', '-2.30', '10.60', '5096409192.00', '800.06', '20161125141142');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000589', 'SZ', '黔轮胎Ａ', '2016-11-25 14:07:15', '', '0', '0', '-0.64', '6.19', '4800124041.76', '218.19', '20161125141142');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000590', 'SZ', '启迪古汉', '2016-11-04 12:17:30', '', '0', '0', '-1.23', '21.73', '4852988431.91', '1511.83', '20161125142509');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000609', 'SZ', '绵石投资', '2016-11-24 16:01:23', '', '0', '0', '9.97', '17.31', '5160033485.82', '35.13', '20161125142509');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000610', 'SZ', '西安旅游', '2016-11-04 12:17:30', '', '0', '0', '0.13', '15.58', '3688532297.58', '154.40', '20161125142509');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000613', 'SZ', '大东海A', '2016-11-25 14:07:15', '', '0', '0', '2.09', '14.67', '5341347000.00', '-1978.28', '20161125141142');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000617', 'SZ', '*ST济柴', '2016-11-25 14:07:15', '', '0', '0', '-1.53', '17.36', '4991680512.00', '-19.34', '20161125141142');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000626', 'SZ', '远大控股', '2016-11-15 09:05:51', '', '0', '0', '-1.31', '30.04', '17982981521.52', '42.70', '20161201164253');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000627', 'SZ', '天茂集团', '2016-11-15 09:21:31', '', '1', '9', '-1.07', '8.29', '35308722952.14', '30.81', '20161201172221');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000631', 'SZ', '顺发恒业', '2016-11-15 09:18:03', '', '0', '0', '1.12', '5.42', '13184253890.56', '43.64', '20161201164253');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000652', 'SZ', '泰达股份', '2016-11-15 09:05:51', '', '0', '0', '-1.63', '6.04', '8912466066.08', '36.68', '20161201164253');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000680', 'SZ', '山推股份', '2016-11-25 14:07:16', '', '0', '0', '-2.91', '6.34', '7866593453.74', '-32.96', '20161125141142');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000702', 'SZ', '正虹科技', '2016-11-25 14:07:16', '', '0', '0', '-1.76', '14.48', '3860868660.48', '9652.17', '20161125141143');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000707', 'SZ', '双环科技', '2016-11-25 14:07:16', '', '0', '0', '-3.29', '9.40', '4362970191.00', '-21.83', '20161125141143');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000720', 'SZ', '新能泰山', '2016-11-25 14:07:16', '', '0', '0', '-1.23', '7.21', '6225546600.00', '-195.28', '20161125141143');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000731', 'SZ', '四川美丰', '2016-11-25 14:07:16', '', '0', '0', '-3.94', '10.49', '6204670852.48', '-59.87', '20161125141143');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000737', 'SZ', '南风化工', '2016-11-25 14:07:17', '', '0', '0', '0.72', '7.02', '3852295200.00', '-24.90', '20161125141144');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000752', 'SZ', '西藏发展', '2016-11-25 14:07:17', '', '0', '0', '-1.26', '18.76', '4948109291.16', '688.19', '20161125141144');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000755', 'SZ', '山西三维', '2016-11-25 14:07:17', '', '0', '0', '-3.32', '9.62', '4514325654.02', '-8.07', '20161125141144');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000758', 'SZ', '中色股份', '2016-11-15 09:18:03', '', '0', '0', '-3.48', '9.14', '18000118795.36', '62.70', '20161125142510');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000759', 'SZ', '中百集团', '2016-11-25 14:07:17', '', '0', '0', '-2.32', '8.84', '6020230060.00', '-54.13', '20161125141144');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000779', 'SZ', '三毛派神', '2016-11-25 14:07:17', '', '0', '0', '0.54', '20.59', '3838820601.80', '-36.83', '20161125141144');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000780', 'SZ', '平庄能源', '2016-11-25 14:07:18', '', '0', '0', '-2.93', '6.62', '6714707864.88', '-12.21', '20161125141145');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000782', 'SZ', '美达股份', '2016-11-25 14:07:18', '', '0', '0', '-4.33', '10.16', '5365898569.68', '-110.43', '20161125141145');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000791', 'SZ', '甘肃电投', '2016-11-25 14:07:18', '', '0', '0', '-3.00', '14.25', '13838548350.00', '-216.40', '20161125141145');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000820', 'SZ', '金城股份', '2016-11-15 09:21:33', '', '1', '9', '2.50', '26.67', '16995330070.74', '122.52', '20161201172221');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000828', 'SZ', '东莞控股', '2016-11-15 09:01:14', '', '0', '0', '1.74', '11.70', '12162348806.40', '14.80', '20161201164254');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000831', 'SZ', '*ST五稀', '2016-11-25 14:07:18', '', '0', '0', '-2.94', '12.20', '11966845568.20', '-102.49', '20161125141145');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000838', 'SZ', '财信发展', '2016-11-15 09:18:04', '', '0', '0', '2.98', '10.37', '11411792702.90', '123.73', '20161125142511');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000852', 'SZ', '石化机械', '2016-11-25 14:07:19', '', '0', '0', '-0.97', '12.28', '7345376433.20', '-18.45', '20161125141145');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000862', 'SZ', '银星能源', '2016-11-25 14:07:19', '', '0', '0', '-1.08', '9.13', '4945109235.22', '-34.65', '20161125141146');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000881', 'SZ', '大连国际', '2016-11-25 14:07:19', '', '0', '0', '-1.01', '23.56', '7278117504.00', '9704.16', '20161125141146');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000885', 'SZ', '同力水泥', '2016-11-25 14:07:19', '', '0', '0', '0.23', '17.19', '8161799674.77', '-215.35', '20161125141146');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000898', 'SZ', '鞍钢股份', '2016-11-25 14:07:19', '', '0', '0', '-0.20', '4.93', '35667602685.71', '-13.07', '20161125141146');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000922', 'SZ', '佳电股份', '2016-11-25 14:07:20', '', '0', '0', '-1.10', '11.70', '6360907140.90', '-11.40', '20161125141146');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000926', 'SZ', '福星股份', '2016-11-15 09:01:15', '', '0', '0', '0.54', '12.95', '12293726038.30', '13.24', '20161201164254');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000928', 'SZ', '中钢国际', '2016-11-15 09:21:34', '', '0', '0', '-3.97', '17.64', '11334795426.36', '24.06', '20161201164254');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000929', 'SZ', '兰州黄河', '2016-11-25 14:07:20', '', '0', '0', '0.49', '20.65', '3836067900.00', '-35.95', '20161125141147');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000930', 'SZ', '中粮生化', '2016-11-25 14:07:20', '', '0', '0', '-0.77', '11.63', '11216101267.45', '-136.45', '20161125141147');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000932', 'SZ', '华菱钢铁', '2016-11-25 14:07:20', '', '0', '0', '-2.15', '5.93', '17882804648.25', '-6.04', '20161125141147');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000935', 'SZ', '四川双马', '2016-11-25 14:07:20', '', '0', '0', '7.39', '35.60', '27178475854.80', '1263.53', '20161125141147');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000957', 'SZ', '中通客车', '2016-11-15 09:05:52', '', '0', '0', '-0.80', '17.38', '10304670407.68', '17.30', '20161201164254');
INSERT INTO `lu_strategy_stock` VALUES ('2', '000962', 'SZ', '*ST东钽', '2016-11-25 14:07:21', '', '0', '0', '-2.65', '11.39', '5021083815.16', '-15.91', '20161125141147');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002018', 'SZ', '华信国际', '2016-11-15 09:21:35', '', '0', '0', '-0.76', '9.18', '20910455733.96', '58.21', '20161201164254');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002064', 'SZ', '华峰氨纶', '2016-11-25 14:07:21', '', '0', '0', '-1.55', '5.07', '8501376000.00', '-28.82', '20161125141147');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002096', 'SZ', '南岭民爆', '2016-11-15 09:21:35', '', '0', '0', '0.23', '17.32', '6430690840.00', '86.05', '20161125142512');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002097', 'SZ', '山河智能', '2016-11-25 14:07:21', '', '0', '0', '-0.97', '10.21', '7711868250.00', '459.04', '20161125141148');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002104', 'SZ', '恒宝股份', '2016-11-15 09:18:04', '', '0', '0', '-1.13', '13.99', '9983935520.00', '43.79', '20161201164255');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002105', 'SZ', '信隆健康', '2016-11-25 14:07:21', '', '0', '0', '1.11', '11.79', '4344615000.00', '-159.96', '20161125141148');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002115', 'SZ', '三维通信', '2016-11-25 14:07:21', '', '0', '0', '0.76', '11.96', '4978457640.00', '-371.25', '20161125141148');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002122', 'SZ', '天马股份', '2016-11-25 14:07:21', '', '0', '0', '2.20', '12.99', '15432120000.00', '428.19', '20161125141148');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002127', 'SZ', '南极电商', '2016-11-15 09:18:04', '', '1', '9', '-0.26', '11.69', '17982253929.08', '120.71', '20161201172221');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002134', 'SZ', '天津普林', '2016-11-25 14:07:21', '', '0', '0', '-4.06', '15.35', '3773793938.80', '-58.50', '20161125141148');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002147', 'SZ', '新光圆成', '2016-11-15 09:21:35', '', '1', '9', '1.11', '17.38', '24439975457.26', '52.60', '20161201172221');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002154', 'SZ', '报 喜 鸟', '2016-11-25 14:07:21', '', '0', '0', '-1.64', '6.00', '7032112440.00', '-667.82', '20161125141148');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002163', 'SZ', '中航三鑫', '2016-11-25 14:07:22', '', '0', '0', '-2.10', '8.38', '6733749000.00', '-120.70', '20161125141148');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002167', 'SZ', '东方锆业', '2016-11-25 14:07:22', '', '0', '0', '-1.53', '12.84', '7972946640.00', '-484.68', '20161125141148');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002181', 'SZ', '粤 传 媒', '2016-11-25 14:07:22', '', '0', '0', '-0.13', '7.86', '9125917247.64', '-48.12', '20161125141148');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002195', 'SZ', '二三四五', '2016-11-15 09:18:05', '', '0', '0', '-0.87', '12.51', '23899922654.40', '50.34', '20161201164255');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002207', 'SZ', '准油股份', '2016-11-25 14:07:22', '', '0', '0', '4.34', '26.18', '6261663756.04', '-66.93', '20161125141149');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002211', 'SZ', '宏达新材', '2016-11-25 14:07:22', '', '0', '0', '4.96', '16.50', '7135850353.50', '-322.74', '20161125141149');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002215', 'SZ', '诺 普 信', '2016-11-25 14:07:22', '', '0', '0', '-1.89', '10.93', '9990854877.12', '-41.26', '20161125141149');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002223', 'SZ', '鱼跃医疗', '2016-11-15 09:18:05', '', '1', '9', '-0.72', '34.37', '22970088044.61', '44.85', '20161201172222');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002231', 'SZ', '奥维通信', '2016-11-25 14:07:22', '', '0', '0', '3.81', '15.81', '5641008000.00', '-812.83', '20161125141149');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002240', 'SZ', '威华股份', '2016-11-25 14:07:22', '', '0', '0', '-1.97', '12.92', '6339895680.00', '-30.74', '20161125141149');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002263', 'SZ', '大 东 南', '2016-11-25 14:07:22', '', '0', '0', '0.27', '3.74', '7025066774.00', '-256.20', '20161125141149');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002265', 'SZ', '西仪股份', '2016-11-25 14:07:23', '', '0', '0', '2.89', '22.43', '6527713180.00', '-536.82', '20161125141149');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002269', 'SZ', '美邦服饰', '2016-11-25 14:07:23', '', '0', '0', '1.20', '5.07', '12806820000.00', '-54.31', '20161125141149');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002270', 'SZ', '华明装备', '2016-11-15 09:18:05', '', '1', '9', '0.00', '16.84', '8523724632.80', '60.30', '20161201172222');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002279', 'SZ', '久其软件', '2016-11-15 09:01:18', '', '0', '0', '-0.92', '19.30', '10450794635.00', '61.06', '20161201164255');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002288', 'SZ', '超华科技', '2016-11-25 14:07:23', '', '0', '0', '0.94', '11.85', '11039978366.40', '8492.29', '20161125141149');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002290', 'SZ', '禾盛新材', '2016-11-15 09:21:36', '', '0', '0', '1.97', '25.93', '6293530716.90', '178.90', '20161201164255');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002291', 'SZ', '星期六', '2016-11-25 14:07:23', '', '0', '0', '0.69', '15.95', '6362804225.25', '447.77', '20161125141149');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002295', 'SZ', '精艺股份', '2016-11-25 14:07:23', '', '0', '0', '6.56', '19.18', '4825688000.00', '600.96', '20161125141149');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002336', 'SZ', '*ST人乐', '2016-11-25 14:07:23', '', '0', '0', '-0.88', '12.40', '4960000000.00', '-27.44', '20161125141150');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002342', 'SZ', '巨力索具', '2016-11-25 14:07:23', '', '0', '0', '-1.60', '6.76', '6489600000.00', '557.53', '20161125141150');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002369', 'SZ', '卓翼科技', '2016-11-25 14:07:23', '', '0', '0', '-1.76', '11.75', '5687034662.50', '-449.92', '20161125141150');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002420', 'SZ', '毅昌股份', '2016-11-25 14:07:23', '', '0', '0', '0.46', '10.84', '4346840000.00', '-110.97', '20161125141150');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002428', 'SZ', '云南锗业', '2016-11-25 14:07:23', '', '0', '0', '-2.26', '15.12', '9875174400.00', '-150.67', '20161125141150');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002442', 'SZ', '龙星化工', '2016-11-25 14:07:23', '', '0', '0', '-0.85', '15.11', '7252800000.00', '5143.83', '20161125141150');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002444', 'SZ', '巨星科技', '2016-11-15 09:18:05', '', '0', '0', '1.41', '18.04', '19397468508.00', '28.66', '20161201164255');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002451', 'SZ', '摩恩电气', '2016-11-25 14:07:24', '', '0', '0', '-4.99', '16.77', '7365384000.00', '5988.12', '20161125141150');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002468', 'SZ', '艾迪西', '2016-11-25 14:07:24', '', '0', '0', '2.40', '33.72', '11187486720.00', '2708.83', '20161125141150');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002528', 'SZ', '英飞拓', '2016-11-25 14:07:24', '', '0', '0', '-1.55', '8.24', '8595956793.60', '-396.86', '20161125141150');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002549', 'SZ', '凯美特气', '2016-11-25 14:07:24', '', '0', '0', '0.09', '11.49', '6514830000.00', '860.61', '20161125141150');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002552', 'SZ', '宝鼎科技', '2016-11-25 14:07:24', '', '0', '0', '-0.93', '18.07', '5421000000.00', '-124.94', '20161125141150');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002564', 'SZ', '天沃科技', '2016-11-25 14:07:24', '', '0', '0', '-2.72', '10.36', '7663416320.00', '-86.27', '20161125141150');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002587', 'SZ', '奥拓电子', '2016-11-15 08:59:25', '', '0', '0', '5.64', '15.37', '5816483655.39', '87.86', '20161201164255');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002613', 'SZ', '北玻股份', '2016-11-15 09:18:05', '', '0', '0', '-1.34', '8.86', '6387174000.00', '388.75', '20161125142513');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002628', 'SZ', '成都路桥', '2016-11-25 14:07:24', '', '0', '0', '-3.42', '9.32', '6872719123.80', '835.08', '20161125141150');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002648', 'SZ', '卫星石化', '2016-11-25 14:07:24', '', '0', '0', '-0.83', '11.88', '9545817600.00', '-838.09', '20161125141150');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002670', 'SZ', '国盛金控', '2016-11-15 09:21:36', '', '1', '9', '-1.90', '35.02', '32783193805.00', '139.68', '20161201172222');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002680', 'SZ', '长生生物', '2016-11-15 09:01:20', '', '1', '9', '-1.11', '20.40', '19775563711.20', '73.85', '20161201172222');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002702', 'SZ', '海欣食品', '2016-11-25 14:07:24', '', '0', '0', '1.05', '19.26', '5741020800.00', '-725.79', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002715', 'SZ', '登云股份', '2016-11-25 14:07:24', '', '0', '0', '0.31', '39.36', '3621120000.00', '-1215.14', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002755', 'SZ', '东方新星', '2016-11-25 14:07:24', '', '0', '0', '-2.16', '50.81', '5149085400.00', '14303.01', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002765', 'SZ', '蓝黛传动', '2016-11-15 09:05:52', '', '0', '0', '-1.69', '30.90', '6595852200.00', '60.65', '20161125142513');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002796', 'SZ', '世嘉科技', '2016-11-25 14:07:24', '', '0', '0', '0.55', '84.67', '6773600000.00', '0.00', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002799', 'SZ', '环球印务', '2016-11-25 14:07:24', '', '0', '0', '-2.68', '61.83', '6183000000.00', '0.00', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002801', 'SZ', '微光股份', '2016-11-25 14:07:24', '', '0', '0', '-1.45', '190.75', '11231360000.00', '0.00', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002802', 'SZ', '洪汇新材', '2016-11-25 14:07:24', '', '0', '0', '3.01', '80.50', '8694000000.00', '0.00', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002808', 'SZ', '苏州恒久', '2016-11-25 14:07:24', '', '0', '0', '-4.60', '54.70', '6564000000.00', '0.00', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002817', 'SZ', '黄山胶囊', '2016-11-25 14:07:24', '', '0', '0', '-1.29', '74.42', '6449981400.00', '0.00', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002818', 'SZ', '富森美', '2016-11-25 14:07:24', '', '0', '0', '10.01', '87.73', '38601200000.00', '0.00', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002820', 'SZ', '桂发祥', '2016-11-25 14:07:24', '', '0', '0', '9.99', '31.81', '4071680000.00', '0.00', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002821', 'SZ', '凯莱英', '2016-11-25 14:07:25', '', '0', '0', '10.00', '58.52', '6604772020.00', '0.00', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '002823', 'SZ', 'N凯中', '2016-11-25 14:07:25', '', '0', '0', '0.00', '19.77', '', '', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300023', 'SZ', '宝德股份', '2016-11-15 09:05:52', '', '0', '0', '0.69', '23.21', '7336838247.75', '84.58', '20161125142513');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300029', 'SZ', '天龙光电', '2016-11-25 14:07:25', '', '0', '0', '-0.93', '14.90', '2980000000.00', '-75.73', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300045', 'SZ', '华力创通', '2016-11-15 09:21:36', '', '0', '0', '0.57', '15.99', '8876368800.00', '258.41', '20161125142513');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300059', 'SZ', '东方财富', '2016-11-15 09:21:36', '', '1', '9', '-1.42', '20.90', '74368915149.10', '78.43', '20161201172222');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300082', 'SZ', '奥克股份', '2016-11-25 14:07:25', '', '0', '0', '-0.69', '8.58', '5782233600.00', '-642.47', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300094', 'SZ', '国联水产', '2016-11-15 09:05:52', '', '0', '0', '1.49', '8.16', '6351545059.20', '59.89', '20161125142513');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300105', 'SZ', '龙源技术', '2016-11-25 14:07:25', '', '0', '0', '-1.90', '9.80', '5029516800.00', '-104.37', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300117', 'SZ', '嘉寓股份', '2016-11-17 05:14:56', '', '0', '0', '-1.13', '6.97', '4995817200.00', '68.57', '20161125142513');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300125', 'SZ', '易世达', '2016-11-25 14:07:25', '', '0', '0', '2.61', '33.86', '3995480000.00', '444.44', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300152', 'SZ', '科融环境', '2016-11-25 14:07:25', '', '0', '0', '-2.17', '8.55', '6094440000.00', '-161.87', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300156', 'SZ', '神雾环保', '2016-11-15 09:21:37', '', '0', '0', '0.32', '25.38', '25634419652.70', '47.13', '20161201164256');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300177', 'SZ', '中海达', '2016-11-25 14:07:25', '', '0', '0', '-0.80', '14.79', '6462100206.69', '766.56', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300224', 'SZ', '正海磁材', '2016-11-15 09:05:52', '', '0', '0', '-2.72', '21.14', '10701433003.24', '67.64', '20161125142513');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300264', 'SZ', '佳创视讯', '2016-11-25 14:07:25', '', '0', '0', '-0.87', '12.57', '5192667000.00', '-617.44', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300280', 'SZ', '南通锻压', '2016-11-25 14:07:25', '', '0', '0', '-1.52', '33.80', '4326400000.00', '692.22', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300293', 'SZ', '蓝英装备', '2016-11-25 14:07:25', '', '0', '0', '0.20', '20.44', '5518800000.00', '-342.36', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300295', 'SZ', '三六五网', '2016-11-15 09:21:37', '', '0', '0', '2.03', '32.60', '6261156000.00', '56.73', '20161201164256');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300330', 'SZ', '华虹计通', '2016-11-25 14:07:25', '', '0', '0', '-1.34', '19.82', '3340012886.00', '-333.00', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300338', 'SZ', '开元仪器', '2016-11-15 09:21:37', '', '0', '0', '3.91', '23.38', '5891760000.00', '455.31', '20161125142513');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300348', 'SZ', '长亮科技', '2016-11-15 09:21:37', '', '0', '0', '-0.94', '30.71', '8973093480.00', '155.22', '20161201164256');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300391', 'SZ', '康跃科技', '2016-11-25 14:07:25', '', '0', '0', '-0.95', '26.99', '4498558250.00', '-4943.47', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300407', 'SZ', '凯发电气', '2016-11-15 09:21:37', '', '0', '0', '-1.81', '21.16', '5755520000.00', '50.21', '20161201164256');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300419', 'SZ', '浩丰科技', '2016-11-15 09:18:06', '', '0', '0', '3.18', '38.23', '7029613313.55', '104.70', '20161122031223');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300462', 'SZ', '华铭智能', '2016-11-15 09:18:06', '', '0', '0', '-2.10', '39.61', '5456673600.00', '128.91', '20161201164256');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300507', 'SZ', '苏奥传感', '2016-11-25 14:07:25', '', '0', '0', '0.60', '145.90', '9727153000.00', '0.00', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300508', 'SZ', '维宏股份', '2016-11-25 14:07:25', '', '0', '0', '-2.82', '161.68', '9186657600.00', '0.00', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300509', 'SZ', '新美星', '2016-11-25 14:07:25', '', '0', '0', '-1.59', '77.39', '6191200000.00', '0.00', '20161125141151');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300512', 'SZ', '中亚股份', '2016-11-25 14:07:25', '', '0', '0', '-1.43', '43.41', '11720700000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300516', 'SZ', '久之洋', '2016-11-25 14:07:25', '', '0', '0', '-3.09', '128.29', '15394800000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300519', 'SZ', '新光药业', '2016-11-25 14:07:25', '', '0', '0', '-2.78', '110.10', '8808000000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300521', 'SZ', '爱司凯', '2016-11-25 14:07:25', '', '0', '0', '-1.29', '79.10', '6328000000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300522', 'SZ', '世名科技', '2016-11-25 14:07:25', '', '0', '0', '-1.77', '131.26', '8751104200.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300525', 'SZ', '博思软件', '2016-11-25 14:07:25', '', '0', '0', '-2.49', '102.87', '7009458930.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300529', 'SZ', '健帆生物', '2016-11-25 14:07:25', '', '0', '0', '-2.24', '61.00', '25132000000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300530', 'SZ', '达志科技', '2016-11-25 14:07:26', '', '0', '0', '-2.79', '92.17', '6451900000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300532', 'SZ', '今天国际', '2016-11-25 14:07:26', '', '0', '0', '1.52', '102.01', '8568840000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300533', 'SZ', '冰川网络', '2016-11-25 14:07:26', '', '0', '0', '-2.37', '164.10', '16410000000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300536', 'SZ', '农尚环境', '2016-11-25 14:07:26', '', '0', '0', '-1.96', '63.48', '5910454197.12', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300539', 'SZ', '横河模具', '2016-11-25 14:07:26', '', '0', '0', '1.02', '58.58', '5565100000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300543', 'SZ', '朗科智能', '2016-11-25 14:07:26', '', '0', '0', '3.27', '154.39', '9263400000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300546', 'SZ', '雄帝科技', '2016-11-25 14:07:26', '', '0', '0', '-3.35', '147.25', '7854315000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300548', 'SZ', '博创科技', '2016-11-25 14:07:26', '', '0', '0', '-0.92', '108.00', '8928360000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300552', 'SZ', '万集科技', '2016-11-25 14:07:26', '', '0', '0', '-2.42', '78.37', '8362079000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300553', 'SZ', '集智股份', '2016-11-25 14:07:26', '', '0', '0', '3.07', '123.66', '5935680000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300557', 'SZ', '理工光科', '2016-11-25 14:07:26', '', '0', '0', '10.00', '91.99', '5120948994.60', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300558', 'SZ', '贝达药业', '2016-11-25 14:07:26', '', '0', '0', '10.01', '79.38', '31831380000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300559', 'SZ', '佳发安泰', '2016-11-25 14:07:26', '', '0', '0', '-3.78', '93.29', '6698222000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300560', 'SZ', '中富通', '2016-11-25 14:07:26', '', '0', '0', '9.99', '67.91', '4761849200.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300561', 'SZ', '汇金科技', '2016-11-25 14:07:26', '', '0', '0', '10.01', '55.06', '3083360000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300562', 'SZ', '乐心医疗', '2016-11-25 14:07:26', '', '0', '0', '10.01', '36.26', '2139340000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300563', 'SZ', '神宇股份', '2016-11-25 14:07:26', '', '0', '0', '9.98', '24.79', '1983200000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300565', 'SZ', '科信技术', '2016-11-25 14:07:26', '', '0', '0', '9.97', '13.90', '2224000000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '300567', 'SZ', '精测电子', '2016-11-25 14:07:26', '', '0', '0', '10.01', '31.55', '2524000000.00', '0.00', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600010', 'SH', '包钢股份', '2016-11-25 14:07:26', '', '0', '0', '-1.00', '2.97', '96705390689.82', '-152.29', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600031', 'SH', '三一重工', '2016-11-25 14:07:26', '', '0', '0', '-1.78', '6.62', '50383900131.14', '-413.76', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600050', 'SH', '中国联通', '2016-11-15 09:18:06', '', '0', '0', '-3.01', '5.80', '122940259091.00', '96.82', '20161125142514');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600058', 'SH', '五矿发展', '2016-11-25 14:07:27', '', '0', '0', '-1.95', '17.58', '18844190299.38', '-6.28', '20161125141152');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600082', 'SH', '海泰发展', '2016-11-25 14:07:27', '', '0', '0', '-0.42', '7.10', '4587422364.60', '-73.60', '20161125141153');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600088', 'SH', '中视传媒', '2016-11-25 14:07:27', '', '0', '0', '-1.64', '23.99', '7950813780.00', '-2933.88', '20161125141153');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600096', 'SH', '云天化', '2016-11-25 14:07:27', '', '0', '0', '-1.71', '9.20', '12156688069.60', '-8.10', '20161125141153');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600099', 'SH', '林海股份', '2016-11-25 14:07:27', '', '0', '0', '-0.98', '14.09', '3087400800.00', '1705.75', '20161125141153');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600107', 'SH', '美尔雅', '2016-11-25 14:07:28', '', '0', '0', '-2.22', '19.84', '7142400000.00', '-736.33', '20161125141153');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600108', 'SH', '亚盛集团', '2016-11-15 09:21:38', '', '0', '0', '1.55', '5.91', '11506268365.11', '155.11', '20161125142514');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600112', 'SH', '天成控股', '2016-11-25 14:07:28', '', '0', '0', '-2.58', '12.84', '6538190222.64', '987.64', '20161125141154');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600119', 'SH', '长江投资', '2016-11-15 09:21:38', '', '0', '0', '-1.93', '23.36', '7180864000.00', '55.22', '20161201164256');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600121', 'SH', '郑州煤电', '2016-11-25 14:07:28', '', '0', '0', '-2.19', '5.81', '5899144950.65', '-14.87', '20161125141154');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600187', 'SH', '国中水务', '2016-11-25 14:07:28', '', '0', '0', '-0.89', '6.65', '9679901116.20', '-124.18', '20161125141154');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600198', 'SH', '大唐电信', '2016-11-25 14:07:29', '', '0', '0', '-0.98', '18.26', '16107300698.72', '-21.54', '20161125141154');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600203', 'SH', '福日电子', '2016-11-15 08:59:28', '', '0', '0', '1.58', '12.85', '5865345492.00', '32.00', '20161201164256');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600206', 'SH', '有研新材', '2016-11-15 09:21:39', '', '0', '0', '-1.85', '11.13', '9335602835.16', '201.46', '20161125142514');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600226', 'SH', '升华拜克', '2016-11-15 09:21:39', '', '0', '0', '1.47', '11.06', '12110511648.20', '45.89', '20161201164256');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600235', 'SH', '民丰特纸', '2016-11-25 14:07:29', '', '0', '0', '-0.24', '12.39', '4352607000.00', '-1548.97', '20161125141154');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600256', 'SH', '广汇能源', '2016-11-25 14:07:29', '', '0', '0', '-1.32', '4.48', '23391982584.32', '233.99', '20161125141155');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600257', 'SH', '大湖股份', '2016-11-25 14:07:29', '', '0', '0', '1.59', '12.16', '5851844206.08', '2259.40', '20161125141155');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600266', 'SH', '北京城建', '2016-11-15 09:21:40', '', '0', '0', '3.85', '14.03', '21985571200.00', '16.63', '20161201164256');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600275', 'SH', '武昌鱼', '2016-11-25 14:07:29', '', '0', '0', '1.46', '18.07', '9194688890.66', '-289.14', '20161125141155');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600280', 'SH', '中央商场', '2016-11-15 09:21:40', '', '0', '0', '-1.09', '9.09', '10438363986.48', '119.88', '20161125142515');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600282', 'SH', '南钢股份', '2016-11-25 14:07:29', '', '0', '0', '1.75', '2.90', '11490010125.30', '-40.81', '20161125141155');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600289', 'SH', '亿阳信通', '2016-11-15 09:21:40', '', '0', '0', '-1.68', '14.66', '9251223331.54', '86.11', '20161201164256');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600302', 'SH', '标准股份', '2016-11-25 14:07:30', '', '0', '0', '0.00', '11.36', '3930671373.44', '-89.07', '20161125141155');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600303', 'SH', '曙光股份', '2016-11-15 09:21:40', '', '0', '0', '-0.57', '10.40', '7026283794.40', '35.52', '20161201164257');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600311', 'SH', '荣华实业', '2016-11-25 14:07:30', '', '0', '0', '-1.76', '7.26', '4832256000.00', '-132.79', '20161125141156');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600321', 'SH', '国栋建设', '2016-11-25 14:07:30', '', '0', '0', '-0.73', '8.18', '12356299000.00', '-169.47', '20161125141156');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600327', 'SH', '大东方', '2016-11-15 09:18:07', '', '0', '0', '3.08', '10.05', '5700021887.85', '30.32', '20161201164257');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600328', 'SH', '兰太实业', '2016-11-15 09:21:41', '', '0', '0', '-1.44', '13.68', '5992265078.64', '111.78', '20161201164257');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600362', 'SH', '江西铜业', '2016-11-25 14:07:30', '', '0', '0', '-3.05', '20.36', '70501170685.80', '177.85', '20161125141156');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600367', 'SH', '红星发展', '2016-11-25 14:07:30', '', '0', '0', '-1.95', '14.59', '4248608000.00', '-27.98', '20161125141156');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600369', 'SH', '西南证券', '2016-11-15 09:21:41', '', '0', '0', '-1.41', '7.69', '43410889163.56', '28.92', '20161125142516');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600376', 'SH', '首开股份', '2016-11-15 09:21:41', '', '0', '0', '0.89', '12.45', '32115587262.90', '17.47', '20161201164257');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600382', 'SH', '广东明珠', '2016-11-15 09:05:53', '', '0', '0', '-1.74', '20.31', '9481210510.02', '58.76', '20161125142516');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600385', 'SH', '山东金泰', '2016-11-25 14:07:31', '', '0', '0', '-1.87', '24.08', '3566420123.84', '89160.50', '20161125141156');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600389', 'SH', '江山股份', '2016-11-25 14:07:31', '', '0', '0', '6.69', '21.85', '6489450000.00', '885.33', '20161125141157');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600416', 'SH', '湘电股份', '2016-11-15 09:21:41', '', '0', '0', '-0.29', '13.64', '12901180193.00', '86.03', '20161201164257');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600418', 'SH', '江淮汽车', '2016-11-15 09:21:42', '', '0', '0', '-0.30', '13.16', '24915987459.72', '26.80', '20161201164257');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600421', 'SH', '仰帆控股', '2016-11-25 14:07:31', '', '0', '0', '-0.25', '23.68', '4631808000.00', '-3216.53', '20161125141157');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600423', 'SH', '柳化股份', '2016-11-25 14:07:31', '', '0', '0', '-2.48', '10.21', '4077338107.73', '-7.80', '20161125141157');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600455', 'SH', '博通股份', '2016-11-25 14:07:31', '', '0', '0', '0.00', '62.37', '3895505460.00', '-701.89', '20161125141157');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600501', 'SH', '航天晨光', '2016-11-25 14:07:31', '', '0', '0', '1.35', '18.72', '7886428992.00', '-573.14', '20161125141157');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600532', 'SH', '宏达矿业', '2016-11-25 14:07:31', '', '0', '0', '-0.80', '17.32', '8938258270.40', '-20.67', '20161125141157');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600536', 'SH', '中国软件', '2016-11-15 09:21:42', '', '0', '0', '-0.87', '29.58', '14629167091.56', '271.56', '20161201164258');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600538', 'SH', '国发股份', '2016-11-25 14:07:32', '', '0', '0', '-1.92', '12.75', '5921115108.75', '-498.83', '20161125141157');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600555', 'SH', '海航创新', '2016-11-15 09:21:42', '', '0', '0', '0.57', '7.04', '9176640000.00', '442.67', '20161125142517');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600569', 'SH', '安阳钢铁', '2016-11-25 14:07:32', '', '0', '0', '-1.27', '3.11', '7444358760.79', '-10.04', '20161125141158');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600582', 'SH', '天地科技', '2016-11-15 09:21:42', '', '0', '0', '3.06', '5.05', '20899873904.60', '23.22', '20161125142517');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600599', 'SH', '熊猫金控', '2016-11-04 12:17:46', '', '0', '0', '4.99', '32.82', '5448120000.00', '459.76', '20161125142517');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600612', 'SH', '老凤祥', '2016-11-15 09:21:43', '', '0', '0', '0.00', '40.51', '21191500619.64', '19.84', '20161201164258');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600630', 'SH', '龙头股份', '2016-11-15 09:21:43', '', '0', '0', '-2.12', '16.66', '7078194206.02', '75.72', '20161125142517');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600634', 'SH', '中技控股', '2016-11-15 09:18:07', '', '0', '0', '-1.33', '18.57', '10691344744.17', '110.98', '20161125142518');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600678', 'SH', '四川金顶', '2016-11-25 14:07:32', '', '0', '0', '0.06', '16.15', '5636188500.00', '-204.51', '20161125141158');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600679', 'SH', '上海凤凰', '2016-11-15 09:18:07', '', '0', '0', '10.01', '28.47', '11450604021.09', '400.79', '20161122031226');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600682', 'SH', '南京新百', '2016-11-25 14:07:32', '', '0', '0', '-0.91', '32.82', '27175495852.14', '1862.61', '20161125141158');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600685', 'SH', '中船防务', '2016-11-15 09:21:43', '', '0', '0', '-0.35', '28.19', '39846744795.82', '37.88', '20161201164258');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600688', 'SH', '上海石化', '2016-11-15 09:18:07', '', '0', '0', '-1.77', '6.11', '65988000000.00', '12.86', '20161201164259');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600696', 'SH', '匹凸匹', '2016-11-25 14:07:32', '', '0', '0', '-0.85', '12.80', '4359239040.00', '-40.54', '20161125141158');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600712', 'SH', '南宁百货', '2016-11-25 14:07:33', '', '0', '0', '-2.00', '11.28', '6143712460.80', '-258.90', '20161125141158');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600751', 'SH', '天海投资', '2016-11-15 09:21:44', '', '0', '0', '-0.58', '10.25', '29718212275.75', '113.32', '20161125142518');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600753', 'SH', '东方银星', '2016-11-25 14:07:33', '', '0', '0', '5.24', '37.94', '4856320000.00', '-481.78', '20161125141159');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600758', 'SH', '红阳能源', '2016-11-25 14:07:33', '', '0', '0', '-2.78', '13.66', '18208261971.82', '-58.20', '20161125141159');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600765', 'SH', '中航重机', '2016-11-25 14:07:33', '', '0', '0', '0.00', '15.19', '11817868608.00', '-37.82', '20161125141159');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600766', 'SH', '园城黄金', '2016-11-25 14:07:34', '', '0', '0', '3.25', '18.74', '4202010644.28', '-691.12', '20161125141159');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600776', 'SH', '东方通信', '2016-11-15 09:18:08', '', '0', '0', '-1.59', '9.31', '11693360595.84', '131.61', '20161125142518');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600778', 'SH', '友好集团', '2016-11-25 14:07:34', '', '0', '0', '-0.93', '11.70', '3644448818.40', '-17.60', '20161125141200');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600792', 'SH', '云煤能源', '2016-11-25 14:07:34', '', '0', '0', '-1.58', '6.22', '6157324792.00', '-37.02', '20161125141200');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600793', 'SH', '宜宾纸业', '2016-11-25 14:07:34', '', '0', '0', '0.00', '30.23', '3183219000.00', '-124.98', '20161125141200');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600811', 'SH', '东方集团', '2016-11-15 09:21:45', '', '0', '0', '-0.68', '7.33', '20944494605.17', '37.65', '20161201164259');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600826', 'SH', '兰生股份', '2016-11-15 09:05:53', '', '0', '0', '-1.16', '29.87', '12564585142.56', '14.72', '20161201164259');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600830', 'SH', '香溢融通', '2016-11-15 09:05:53', '', '0', '0', '0.00', '12.27', '5574540105.69', '36.52', '20161125142519');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600860', 'SH', '京城股份', '2016-11-25 14:07:35', '', '0', '0', '4.89', '12.22', '5156840000.00', '-23.76', '20161125141200');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600870', 'SH', '厦华电子', '2016-11-15 09:18:08', '', '0', '0', '-1.24', '10.32', '5399420542.80', '655.27', '20161122031228');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600875', 'SH', '东方电气', '2016-11-25 14:07:35', '', '0', '0', '-0.49', '10.22', '23883121760.96', '-27.39', '20161125141200');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600877', 'SH', '中国嘉陵', '2016-11-15 09:21:46', '', '0', '0', '-1.95', '9.06', '6226775282.40', '-33.00', '20161125142519');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600881', 'SH', '亚泰集团', '2016-11-25 14:07:35', '', '0', '0', '-0.89', '5.57', '14481697755.09', '135.81', '20161125141201');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600891', 'SH', '秋林集团', '2016-11-15 09:05:53', '', '1', '9', '-0.28', '10.74', '6632871524.22', '30.20', '20161201172222');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600961', 'SH', '株冶集团', '2016-11-25 14:07:35', '', '0', '0', '-2.38', '11.88', '6266200018.32', '-18.93', '20161125141201');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600976', 'SH', '健民集团', '2016-11-15 08:59:31', '', '0', '0', '-2.68', '33.47', '5134251142.00', '74.18', '20161125142520');
INSERT INTO `lu_strategy_stock` VALUES ('2', '600981', 'SH', '汇鸿集团', '2016-11-15 09:18:09', '', '0', '0', '-1.29', '9.21', '20652809698.32', '16.31', '20161201164259');
INSERT INTO `lu_strategy_stock` VALUES ('2', '601001', 'SH', '大同煤业', '2016-11-25 14:07:35', '', '0', '0', '-2.22', '7.04', '11782848000.00', '-69.16', '20161125141201');
INSERT INTO `lu_strategy_stock` VALUES ('2', '601003', 'SH', '柳钢股份', '2016-11-25 14:07:35', '', '0', '0', '4.84', '4.77', '12224523564.00', '-53.09', '20161125141201');
INSERT INTO `lu_strategy_stock` VALUES ('2', '601117', 'SH', '中国化学', '2016-11-02 05:49:25', '', '0', '0', '-0.15', '6.54', '32261820000.00', '14.72', '20161125142520');
INSERT INTO `lu_strategy_stock` VALUES ('2', '601155', 'SH', '新城控股', '2016-11-15 09:18:09', '', '1', '9', '2.00', '11.74', '26068484343.64', '11.48', '20161201172222');
INSERT INTO `lu_strategy_stock` VALUES ('2', '601258', 'SH', '庞大集团', '2016-11-15 09:21:47', '', '0', '0', '0.71', '2.85', '19023930695.70', '108.28', '20161122031229');
INSERT INTO `lu_strategy_stock` VALUES ('2', '601377', 'SH', '兴业证券', '2016-11-15 09:21:47', '', '0', '0', '-1.02', '8.72', '58394976997.28', '21.68', '20161201164259');
INSERT INTO `lu_strategy_stock` VALUES ('2', '601558', 'SH', '华锐风电', '2016-11-25 14:07:36', '', '0', '0', '-0.71', '2.78', '16765068000.00', '-15.88', '20161125141201');
INSERT INTO `lu_strategy_stock` VALUES ('2', '601666', 'SH', '平煤股份', '2016-11-25 14:07:36', '', '0', '0', '-1.38', '5.71', '13482252047.22', '-25.13', '20161125141201');
INSERT INTO `lu_strategy_stock` VALUES ('2', '601699', 'SH', '潞安环能', '2016-11-25 14:07:36', '', '0', '0', '-2.13', '9.64', '28837184688.00', '194.75', '20161125141201');
INSERT INTO `lu_strategy_stock` VALUES ('2', '601801', 'SH', '皖新传媒', '2016-11-15 09:18:09', '', '0', '0', '2.05', '16.90', '33617560055.30', '36.07', '20161201164259');
INSERT INTO `lu_strategy_stock` VALUES ('2', '601808', 'SH', '中海油服', '2016-11-25 14:07:36', '', '0', '0', '2.35', '13.48', '64321060160.00', '-6.94', '20161125141201');
INSERT INTO `lu_strategy_stock` VALUES ('2', '601857', 'SH', '中国石油', '2016-11-25 14:07:36', '', '0', '0', '-1.04', '7.59', '1389129221638.62', '204.92', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '601866', 'SH', '中海集运', '2016-11-25 14:07:36', '', '0', '0', '-2.64', '4.43', '51756243750.00', '-20.30', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '601882', 'SH', '海天精工', '2016-11-25 14:07:36', '', '0', '0', '10.05', '6.79', '3544380000.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '601989', 'SH', '中国重工', '2016-11-25 14:07:36', '', '0', '0', '-0.85', '6.96', '127797188859.36', '572.39', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '601999', 'SH', '出版传媒', '2016-11-15 09:18:09', '', '0', '0', '-0.90', '13.15', '7244528305.00', '62.53', '20161125142520');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603012', 'SH', '创力集团', '2016-11-15 09:21:47', '', '0', '0', '-1.12', '12.34', '7855150400.00', '73.03', '20161125142520');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603016', 'SH', '新宏泰', '2016-11-25 14:07:36', '', '0', '0', '-9.19', '53.68', '7953228800.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603031', 'SH', '安德利', '2016-11-25 14:07:36', '', '0', '0', '-4.08', '75.27', '6021600000.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603060', 'SH', '国检集团', '2016-11-25 14:07:36', '', '0', '0', '10.00', '37.52', '8254400000.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603069', 'SH', '海汽集团', '2016-11-25 14:07:36', '', '0', '0', '-1.11', '23.09', '7296440000.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603090', 'SH', '宏盛股份', '2016-11-25 14:07:36', '', '0', '0', '-3.80', '57.94', '5794000000.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603159', 'SH', '上海亚虹', '2016-11-25 14:07:36', '', '0', '0', '-1.35', '57.61', '5761000000.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603160', 'SH', '汇顶科技', '2016-11-25 14:07:36', '', '0', '0', '-0.06', '139.15', '61921750000.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603189', 'SH', '网达软件', '2016-11-25 14:07:36', '', '0', '0', '-4.71', '47.94', '10585152000.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603203', 'SH', '快克股份', '2016-11-25 14:07:36', '', '0', '0', '10.00', '67.79', '6236680000.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603227', 'SH', '雪峰科技', '2016-11-15 09:18:09', '', '0', '0', '-1.91', '9.74', '6415738000.00', '216.09', '20161125142520');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603299', 'SH', '井神股份', '2016-11-25 14:07:36', '', '0', '0', '1.48', '22.58', '12632155200.00', '1402.02', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603333', 'SH', '明星电缆', '2016-11-25 14:07:37', '', '0', '0', '-0.88', '10.13', '5267650650.00', '-287.07', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603336', 'SH', 'N宏辉', '2016-11-25 14:07:37', '', '0', '0', '0.00', '13.41', '', '', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603338', 'SH', '浙江鼎力', '2016-11-15 09:05:54', '', '0', '0', '-2.87', '52.06', '8459750000.00', '49.29', '20161201164259');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603339', 'SH', '四方冷链', '2016-11-25 14:07:37', '', '0', '0', '-3.82', '47.05', '9729940000.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603393', 'SH', '新天然气', '2016-11-25 14:07:37', '', '0', '0', '-2.83', '68.01', '10881600000.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603508', 'SH', '思维列控', '2016-11-25 14:07:37', '', '0', '0', '-2.47', '92.55', '14808000000.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603528', 'SH', '多伦科技', '2016-11-25 14:07:37', '', '0', '0', '-1.16', '86.10', '17795148000.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603556', 'SH', '海兴电力', '2016-11-25 14:07:37', '', '0', '0', '0.32', '64.84', '24207365600.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603633', 'SH', '徕木股份', '2016-11-25 14:07:37', '', '0', '0', '9.97', '14.23', '1712580500.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603663', 'SH', '三祥新材', '2016-11-25 14:07:37', '', '0', '0', '-3.11', '47.11', '6319806500.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603727', 'SH', '博迈科', '2016-11-25 14:07:37', '', '0', '0', '10.01', '32.97', '7719760650.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603788', 'SH', '宁波高发', '2016-11-15 08:59:31', '', '0', '0', '-0.75', '48.81', '6880745700.00', '48.45', '20161201164259');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603799', 'SH', '华友钴业', '2016-11-25 14:07:37', '', '0', '0', '-1.34', '34.70', '18571093000.00', '-90.16', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603806', 'SH', '福斯特', '2016-11-15 09:18:09', '', '0', '0', '-1.94', '51.54', '20719080000.00', '24.49', '20161201164300');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603816', 'SH', '顾家家居', '2016-11-25 14:07:37', '', '0', '0', '-2.66', '58.60', '24172500000.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603858', 'SH', '步长制药', '2016-11-25 14:07:37', '', '0', '0', '10.00', '107.11', '73027598000.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603859', 'SH', '能科股份', '2016-11-25 14:07:37', '', '0', '0', '-3.07', '54.54', '6193562400.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603900', 'SH', '通灵珠宝', '2016-11-25 14:07:37', '', '0', '0', '0.00', '20.52', '4990373712.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603919', 'SH', '金徽酒', '2016-11-25 14:07:37', '', '0', '0', '-1.63', '35.02', '9805600000.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('2', '603987', 'SH', '康德莱', '2016-11-25 14:07:37', '', '0', '0', '10.03', '16.56', '3482402400.00', '0.00', '20161125141202');
INSERT INTO `lu_strategy_stock` VALUES ('3', '000796', 'SZ', '凯撒旅游', '2016-11-08 01:44:26', '', '1', '3', '-2.55', '17.21', '13819634440.18', '50.36', '20161108023410');
INSERT INTO `lu_strategy_stock` VALUES ('3', '000810', 'SZ', '创维数字', '2016-11-04 05:20:21', '', '1', '4', '-1.95', '16.58', '17152976282.40', '32.21', '20161108023410');
INSERT INTO `lu_strategy_stock` VALUES ('3', '002108', 'SZ', '沧州明珠', '2016-11-07 11:29:43', '', '1', '4', '-0.13', '22.45', '13884383626.60', '31.08', '20161108023410');
INSERT INTO `lu_strategy_stock` VALUES ('3', '002271', 'SZ', '东方雨虹', '2016-11-08 01:44:27', '', '1', '3', '-1.33', '22.32', '19727383527.36', '21.90', '20161108023410');
INSERT INTO `lu_strategy_stock` VALUES ('3', '002400', 'SZ', '省广股份', '2016-11-04 05:20:22', '', '1', '4', '0.15', '13.30', '17835679848.00', '28.78', '20161108023410');
INSERT INTO `lu_strategy_stock` VALUES ('3', '002407', 'SZ', '多氟多', '2016-11-04 05:20:22', '', '1', '4', '-0.85', '32.52', '20425987185.24', '52.55', '20161108023410');
INSERT INTO `lu_strategy_stock` VALUES ('3', '002410', 'SZ', '广联达', '2016-11-04 05:20:22', '', '1', '4', '-0.20', '15.31', '17137431286.09', '48.20', '20161108023410');
INSERT INTO `lu_strategy_stock` VALUES ('3', '002470', 'SZ', '金正大', '2016-11-04 07:04:40', '', '1', '4', '-0.53', '7.46', '23432101965.10', '20.54', '20161108023410');
INSERT INTO `lu_strategy_stock` VALUES ('3', '002626', 'SZ', '金达威', '2016-11-03 11:10:03', '', '1', '2', '0.64', '15.71', '9684931073.17', '49.30', '20161108023410');
INSERT INTO `lu_strategy_stock` VALUES ('3', '002664', 'SZ', '信质电机', '2016-11-08 01:44:27', '', '1', '3', '0.31', '25.76', '10304515200.00', '42.76', '20161108023410');
INSERT INTO `lu_strategy_stock` VALUES ('3', '002707', 'SZ', '众信旅游', '2016-11-08 01:44:27', '', '1', '3', '-0.98', '18.14', '15309359663.20', '67.56', '20161108023410');
INSERT INTO `lu_strategy_stock` VALUES ('3', '300017', 'SZ', '网宿科技', '2016-11-04 05:20:22', '', '1', '4', '-2.30', '58.16', '46495378753.92', '39.09', '20161108023410');
INSERT INTO `lu_strategy_stock` VALUES ('3', '300023', 'SZ', '宝德股份', '2016-11-03 11:10:03', '', '1', '4', '0.39', '20.50', '6480188887.50', '74.71', '20161108023410');
INSERT INTO `lu_strategy_stock` VALUES ('3', '300072', 'SZ', '三聚环保', '2016-11-07 11:29:44', '', '1', '4', '0.99', '46.03', '54985351920.40', '37.87', '20161108023410');
INSERT INTO `lu_strategy_stock` VALUES ('3', '300182', 'SZ', '捷成股份', '2016-11-08 01:44:27', '', '1', '3', '-2.28', '11.15', '28571513806.90', '37.35', '20161108023410');
INSERT INTO `lu_strategy_stock` VALUES ('3', '300221', 'SZ', '银禧科技', '2016-11-04 05:15:48', '', '1', '4', '0.71', '21.35', '8588421800.00', '55.61', '20161108023410');
INSERT INTO `lu_strategy_stock` VALUES ('3', '300265', 'SZ', '通光线缆', '2016-11-03 11:10:05', '', '1', '4', '-0.77', '16.75', '5653125000.00', '51.31', '20161108023411');
INSERT INTO `lu_strategy_stock` VALUES ('3', '300284', 'SZ', '苏交科', '2016-11-04 05:20:23', '', '1', '4', '0.00', '21.39', '11899924795.80', '33.84', '20161108023411');
INSERT INTO `lu_strategy_stock` VALUES ('3', '300409', 'SZ', '道氏技术', '2016-11-03 11:10:06', '', '1', '4', '0.30', '42.84', '9210600000.00', '98.18', '20161108023411');
INSERT INTO `lu_strategy_stock` VALUES ('3', '300476', 'SZ', '胜宏科技', '2016-11-03 03:42:22', '', '1', '4', '-1.16', '23.84', '8913776000.00', '46.27', '20161108023411');
INSERT INTO `lu_strategy_stock` VALUES ('3', '300497', 'SZ', '富祥股份', '2016-11-03 11:10:07', '', '1', '4', '0.52', '74.15', '8307562087.50', '53.50', '20161108023411');
INSERT INTO `lu_strategy_stock` VALUES ('3', '600297', 'SH', '广汇汽车', '2016-11-04 07:04:41', '', '1', '4', '1.31', '8.53', '46918417783.34', '20.01', '20161108023411');
INSERT INTO `lu_strategy_stock` VALUES ('3', '600487', 'SH', '亨通光电', '2016-11-04 05:15:48', '', '1', '4', '0.94', '18.29', '22702811198.85', '17.34', '20161108023411');
INSERT INTO `lu_strategy_stock` VALUES ('3', '600537', 'SH', '亿晶光电', '2016-11-07 11:29:45', '', '1', '4', '-0.39', '7.68', '9034439178.24', '19.15', '20161108023411');
INSERT INTO `lu_strategy_stock` VALUES ('3', '601199', 'SH', '江南水务', '2016-11-03 11:10:08', '', '1', '4', '-0.58', '8.64', '8080143586.56', '25.56', '20161108023411');

-- -----------------------------
-- Table structure for `lu_strategy_stockfilter`
-- -----------------------------
DROP TABLE IF EXISTS `lu_strategy_stockfilter`;
CREATE TABLE `lu_strategy_stockfilter` (
  `name` varchar(100) NOT NULL,
  `type` varchar(100) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `attr` varchar(255) DEFAULT NULL,
  `use_type` varchar(30) NOT NULL DEFAULT 'filter',
  `ord` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------
-- Records of `lu_strategy_stockfilter`
-- -----------------------------
INSERT INTO `lu_strategy_stockfilter` VALUES ('betaStockFilter', 'num', 'Beta过滤器', '过滤器描述字段', 'filter', '2');
INSERT INTO `lu_strategy_stockfilter` VALUES ('cansellStockFilter', 'num_day2', '禁售过滤器', '过滤器描述字段', 'filter', '4');
INSERT INTO `lu_strategy_stockfilter` VALUES ('codeStockFilter', 'text', '股票代码选择器', '选择器描述字段', 'condition', '0');
INSERT INTO `lu_strategy_stockfilter` VALUES ('dongshizhangStockFilter', 'bool', '董事长过滤器', '过滤器描述字段', 'filter', '2');
INSERT INTO `lu_strategy_stockfilter` VALUES ('financerateStockFilter', 'num_menu', '财务过滤器', '过滤器描述字段', 'filter', '10');
INSERT INTO `lu_strategy_stockfilter` VALUES ('hangyeStockFilter', 'num_menu', '行业过滤器', '过滤器描述字段<a href=\"/index.php?s=/admin/lu_strategy/hangye.html\" target=\"_blank\">查看行业名称</a>', 'filter', '2');
INSERT INTO `lu_strategy_stockfilter` VALUES ('jinglirunstableStockFilter', 'bool', '净利润稳定性过滤器', '过滤器描述字段', 'filter', '4');
INSERT INTO `lu_strategy_stockfilter` VALUES ('jingzichanshouyilvhangyeStockFilter', 'num', '行业净资产收益率过滤器', '过滤器描述字段', 'filter', '6');
INSERT INTO `lu_strategy_stockfilter` VALUES ('jingzichanshouyilvStockFilter', 'num', '净资产收益率过滤器', '过滤器描述字段', 'filter', '2');
INSERT INTO `lu_strategy_stockfilter` VALUES ('nameStockFilter', 'str', '名字过滤器', '过滤器描述字段', 'filter', '2');
INSERT INTO `lu_strategy_stockfilter` VALUES ('orgholderrateStockFilter', 'num', '机构持股比率过滤器', '过滤器描述字段', 'filter', '4');
INSERT INTO `lu_strategy_stockfilter` VALUES ('priceStockFilter', 'num', '价格过滤器', '过滤器描述字段', 'filter', '2');
INSERT INTO `lu_strategy_stockfilter` VALUES ('shangshiriqiStockFilter', 'num', '上市时间过滤器', '过滤器描述字段', 'filter', '2');
INSERT INTO `lu_strategy_stockfilter` VALUES ('shiyinglvttmStockFilter', 'num', '市盈率（TTM）过滤器', '过滤器描述字段', 'filter', '2');
INSERT INTO `lu_strategy_stockfilter` VALUES ('top1holderrateStockFilter', 'num', '第一持股人比率过滤器', '过滤器描述字段', 'filter', '4');
INSERT INTO `lu_strategy_stockfilter` VALUES ('xiadieStockFilter', 'num_day1', '涨跌幅过滤器', '过滤器描述字段', 'filter', '6');
INSERT INTO `lu_strategy_stockfilter` VALUES ('xianjinliuStockFilter', 'num_menu', '现金流变动比率过滤器', '过滤器描述字段', 'filter', '8');
INSERT INTO `lu_strategy_stockfilter` VALUES ('xiaoshoumaolilvStockFilter', 'num', '销售贸易率过滤器', '过滤器描述字段', 'filter', '2');
INSERT INTO `lu_strategy_stockfilter` VALUES ('yewuStockFilter', 'str', '业务关键词过滤器', '过滤器描述字段', 'filter', '4');
INSERT INTO `lu_strategy_stockfilter` VALUES ('zichanfuzhailvStockFilter', 'num', '资产负债率过滤器', '过滤器描述字段', 'filter', '2');
INSERT INTO `lu_strategy_stockfilter` VALUES ('zongshizhiStockFilter', 'num', '总市值过滤器', '过滤器描述字段', 'filter', '2');

-- -----------------------------
-- Table structure for `ot_action`
-- -----------------------------
DROP TABLE IF EXISTS `ot_action`;
CREATE TABLE `ot_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text NOT NULL COMMENT '行为规则',
  `log` text NOT NULL COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `ot_action`
-- -----------------------------
INSERT INTO `ot_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '[user|get_nickname]在[time|time_format]登录了后台', '1', '1', '1387181220');
INSERT INTO `ot_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '', '2', '0', '1380173180');
INSERT INTO `ot_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '1', '1383285646');
INSERT INTO `ot_action` VALUES ('4', 'add_document', '发表文档', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '[user|get_nickname]在[time|time_format]发表了一篇文章。\r\n表[model]，记录编号[record]。', '2', '0', '1386139726');
INSERT INTO `ot_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '0', '1383285551');
INSERT INTO `ot_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '1', '1383294988');
INSERT INTO `ot_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057');
INSERT INTO `ot_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963');
INSERT INTO `ot_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '1', '1383296301');
INSERT INTO `ot_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392');
INSERT INTO `ot_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '1', '1383296765');

-- -----------------------------
-- Table structure for `ot_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `ot_action_log`;
CREATE TABLE `ot_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `ot_action_log`
-- -----------------------------
INSERT INTO `ot_action_log` VALUES ('1', '1', '1', '0', 'member', '1', 'admin在2016-11-25 16:00登录了后台', '1', '1480060849');
INSERT INTO `ot_action_log` VALUES ('2', '1', '1', '0', 'member', '1', 'admin在2016-11-26 10:00登录了后台', '1', '1480125632');
INSERT INTO `ot_action_log` VALUES ('3', '1', '1', '0', 'member', '1', 'admin在2016-11-28 10:58登录了后台', '1', '1480301886');
INSERT INTO `ot_action_log` VALUES ('4', '1', '1', '0', 'member', '1', 'admin在2016-11-29 09:29登录了后台', '1', '1480382996');
INSERT INTO `ot_action_log` VALUES ('5', '1', '1', '2130706433', 'member', '1', 'admin在2016-11-30 18:05登录了后台', '1', '1480500334');
INSERT INTO `ot_action_log` VALUES ('6', '1', '1', '2130706433', 'member', '1', 'admin在2016-12-01 13:40登录了后台', '1', '1480570855');
INSERT INTO `ot_action_log` VALUES ('7', '1', '1', '2130706433', 'member', '1', 'admin在2016-12-02 13:07登录了后台', '1', '1480655240');
INSERT INTO `ot_action_log` VALUES ('8', '1', '1', '2130706433', 'member', '1', 'admin在2016-12-05 11:11登录了后台', '1', '1480907465');
INSERT INTO `ot_action_log` VALUES ('9', '1', '1', '2130706433', 'member', '1', 'admin在2016-12-05 11:20登录了后台', '1', '1480908056');

-- -----------------------------
-- Table structure for `ot_addons`
-- -----------------------------
DROP TABLE IF EXISTS `ot_addons`;
CREATE TABLE `ot_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `ot_addons`
-- -----------------------------
INSERT INTO `ot_addons` VALUES ('15', 'EditorForAdmin', '后台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"500px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1383126253', '0');
INSERT INTO `ot_addons` VALUES ('2', 'SiteStat', '站点统计信息', '统计站点的基础信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"1\",\"display\":\"1\",\"status\":\"0\"}', 'thinkphp', '0.1', '1379512015', '0');
INSERT INTO `ot_addons` VALUES ('3', 'DevTeam', '开发团队信息', '开发团队成员信息', '1', '{\"title\":\"OneThink\\u5f00\\u53d1\\u56e2\\u961f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512022', '0');
INSERT INTO `ot_addons` VALUES ('4', 'SystemInfo', '系统环境信息', '用于显示一些服务器的信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512036', '0');
INSERT INTO `ot_addons` VALUES ('5', 'Editor', '前台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"300px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1379830910', '0');
INSERT INTO `ot_addons` VALUES ('6', 'Attachment', '附件', '用于文档模型上传附件', '1', 'null', 'thinkphp', '0.1', '1379842319', '1');
INSERT INTO `ot_addons` VALUES ('9', 'SocialComment', '通用社交化评论', '集成了各种社交化评论插件，轻松集成到系统中。', '1', '{\"comment_type\":\"1\",\"comment_uid_youyan\":\"\",\"comment_short_name_duoshuo\":\"\",\"comment_data_list_duoshuo\":\"\"}', 'thinkphp', '0.1', '1380273962', '0');

-- -----------------------------
-- Table structure for `ot_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `ot_attachment`;
CREATE TABLE `ot_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '附件显示名',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件类型',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '资源ID',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联记录ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '附件大小',
  `dir` int(12) unsigned NOT NULL DEFAULT '0' COMMENT '上级目录ID',
  `sort` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_record_status` (`record_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件表';


-- -----------------------------
-- Table structure for `ot_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `ot_attribute`;
CREATE TABLE `ot_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL,
  `validate_time` tinyint(1) unsigned NOT NULL,
  `error_info` varchar(100) NOT NULL,
  `validate_type` varchar(25) NOT NULL,
  `auto_rule` varchar(100) NOT NULL,
  `auto_time` tinyint(1) unsigned NOT NULL,
  `auto_type` varchar(25) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `ot_attribute`
-- -----------------------------
INSERT INTO `ot_attribute` VALUES ('1', 'uid', '用户ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1384508362', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('2', 'name', '标识', 'char(40) NOT NULL ', 'string', '', '同一根节点下标识不重复', '1', '', '1', '0', '1', '1383894743', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('3', 'title', '标题', 'char(80) NOT NULL ', 'string', '', '文档标题', '1', '', '1', '0', '1', '1383894778', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('4', 'category_id', '所属分类', 'int(10) unsigned NOT NULL ', 'string', '', '', '0', '', '1', '0', '1', '1384508336', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('5', 'description', '描述', 'char(140) NOT NULL ', 'textarea', '', '', '1', '', '1', '0', '1', '1383894927', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('6', 'root', '根节点', 'int(10) unsigned NOT NULL ', 'num', '0', '该文档的顶级文档编号', '0', '', '1', '0', '1', '1384508323', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('7', 'pid', '所属ID', 'int(10) unsigned NOT NULL ', 'num', '0', '父文档编号', '0', '', '1', '0', '1', '1384508543', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('8', 'model_id', '内容模型ID', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '该文档所对应的模型', '0', '', '1', '0', '1', '1384508350', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('9', 'type', '内容类型', 'tinyint(3) unsigned NOT NULL ', 'select', '2', '', '1', '1:目录\r\n2:主题\r\n3:段落', '1', '0', '1', '1384511157', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('10', 'position', '推荐位', 'smallint(5) unsigned NOT NULL ', 'checkbox', '0', '多个推荐则将其推荐值相加', '1', '1:列表推荐\r\n2:频道页推荐\r\n4:首页推荐', '1', '0', '1', '1383895640', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('11', 'link_id', '外链', 'int(10) unsigned NOT NULL ', 'num', '0', '0-非外链，大于0-外链ID,需要函数进行链接与编号的转换', '1', '', '1', '0', '1', '1383895757', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('12', 'cover_id', '封面', 'int(10) unsigned NOT NULL ', 'picture', '0', '0-无封面，大于0-封面图片ID，需要函数处理', '1', '', '1', '0', '1', '1384147827', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('13', 'display', '可见性', 'tinyint(3) unsigned NOT NULL ', 'radio', '1', '', '1', '0:不可见\r\n1:所有人可见', '1', '0', '1', '1386662271', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `ot_attribute` VALUES ('14', 'deadline', '截至时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '0-永久有效', '1', '', '1', '0', '1', '1387163248', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `ot_attribute` VALUES ('15', 'attach', '附件数量', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1387260355', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `ot_attribute` VALUES ('16', 'view', '浏览量', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895835', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('17', 'comment', '评论数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895846', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('18', 'extend', '扩展统计字段', 'int(10) unsigned NOT NULL ', 'num', '0', '根据需求自行使用', '0', '', '1', '0', '1', '1384508264', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('19', 'level', '优先级', 'int(10) unsigned NOT NULL ', 'num', '0', '越高排序越靠前', '1', '', '1', '0', '1', '1383895894', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('20', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '1', '0', '1', '1383895903', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('21', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '0', '', '1', '0', '1', '1384508277', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('22', 'status', '数据状态', 'tinyint(4) NOT NULL ', 'radio', '0', '', '0', '-1:删除\r\n0:禁用\r\n1:正常\r\n2:待审核\r\n3:草稿', '1', '0', '1', '1384508496', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('23', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '2', '0', '1', '1384511049', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('24', 'content', '文章内容', 'text NOT NULL ', 'editor', '', '', '1', '', '2', '0', '1', '1383896225', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('25', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '参照display方法参数的定义', '1', '', '2', '0', '1', '1383896190', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('26', 'bookmark', '收藏数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '2', '0', '1', '1383896103', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('27', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '3', '0', '1', '1387260461', '1383891252', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `ot_attribute` VALUES ('28', 'content', '下载详细描述', 'text NOT NULL ', 'editor', '', '', '1', '', '3', '0', '1', '1383896438', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('29', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '3', '0', '1', '1383896429', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('30', 'file_id', '文件ID', 'int(10) unsigned NOT NULL ', 'file', '0', '需要函数处理', '1', '', '3', '0', '1', '1383896415', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('31', 'download', '下载次数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '3', '0', '1', '1383896380', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `ot_attribute` VALUES ('32', 'size', '文件大小', 'bigint(20) unsigned NOT NULL ', 'num', '0', '单位bit', '1', '', '3', '0', '1', '1383896371', '1383891252', '', '0', '', '', '', '0', '');

-- -----------------------------
-- Table structure for `ot_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `ot_auth_extend`;
CREATE TABLE `ot_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `ot_auth_extend`
-- -----------------------------
INSERT INTO `ot_auth_extend` VALUES ('1', '1', '1');
INSERT INTO `ot_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `ot_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `ot_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `ot_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `ot_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `ot_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `ot_auth_extend` VALUES ('1', '37', '1');

-- -----------------------------
-- Table structure for `ot_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `ot_auth_group`;
CREATE TABLE `ot_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ot_auth_group`
-- -----------------------------
INSERT INTO `ot_auth_group` VALUES ('1', 'admin', '1', '默认用户组', '', '1', '1,2,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,81,82,83,84,86,87,88,89,90,91,92,93,94,95,96,97,100,102,103,105,106');
INSERT INTO `ot_auth_group` VALUES ('2', 'admin', '1', '测试用户', '测试用户', '1', '1,2,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,82,83,84,88,89,90,91,92,93,96,97,100,102,103,195');

-- -----------------------------
-- Table structure for `ot_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `ot_auth_group_access`;
CREATE TABLE `ot_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `ot_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `ot_auth_rule`;
CREATE TABLE `ot_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=221 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ot_auth_rule`
-- -----------------------------
INSERT INTO `ot_auth_rule` VALUES ('1', 'admin', '2', 'Admin/Index/index', '首页', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('2', 'admin', '2', 'Admin/Article/mydocument', '内容', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('3', 'admin', '2', 'Admin/User/index', '用户', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('4', 'admin', '2', 'Admin/Addons/index', '扩展', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('5', 'admin', '2', 'Admin/Config/group', '系统', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('7', 'admin', '1', 'Admin/article/add', '新增', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('8', 'admin', '1', 'Admin/article/edit', '编辑', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('9', 'admin', '1', 'Admin/article/setStatus', '改变状态', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('10', 'admin', '1', 'Admin/article/update', '保存', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('11', 'admin', '1', 'Admin/article/autoSave', '保存草稿', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('12', 'admin', '1', 'Admin/article/move', '移动', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('13', 'admin', '1', 'Admin/article/copy', '复制', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('14', 'admin', '1', 'Admin/article/paste', '粘贴', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('15', 'admin', '1', 'Admin/article/permit', '还原', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('16', 'admin', '1', 'Admin/article/clear', '清空', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('17', 'admin', '1', 'Admin/article/index', '文档列表', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('18', 'admin', '1', 'Admin/article/recycle', '回收站', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('19', 'admin', '1', 'Admin/User/addaction', '新增用户行为', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('20', 'admin', '1', 'Admin/User/editaction', '编辑用户行为', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('21', 'admin', '1', 'Admin/User/saveAction', '保存用户行为', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('22', 'admin', '1', 'Admin/User/setStatus', '变更行为状态', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('23', 'admin', '1', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('24', 'admin', '1', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('25', 'admin', '1', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('26', 'admin', '1', 'Admin/User/index', '用户信息', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('27', 'admin', '1', 'Admin/User/action', '用户行为', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('28', 'admin', '1', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('29', 'admin', '1', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('30', 'admin', '1', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('31', 'admin', '1', 'Admin/AuthManager/createGroup', '新增', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('32', 'admin', '1', 'Admin/AuthManager/editGroup', '编辑', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('33', 'admin', '1', 'Admin/AuthManager/writeGroup', '保存用户组', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('34', 'admin', '1', 'Admin/AuthManager/group', '授权', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('35', 'admin', '1', 'Admin/AuthManager/access', '访问授权', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('36', 'admin', '1', 'Admin/AuthManager/user', '成员授权', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('37', 'admin', '1', 'Admin/AuthManager/removeFromGroup', '解除授权', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('38', 'admin', '1', 'Admin/AuthManager/addToGroup', '保存成员授权', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('39', 'admin', '1', 'Admin/AuthManager/category', '分类授权', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('40', 'admin', '1', 'Admin/AuthManager/addToCategory', '保存分类授权', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('41', 'admin', '1', 'Admin/AuthManager/index', '权限管理', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('42', 'admin', '1', 'Admin/Addons/create', '创建', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('43', 'admin', '1', 'Admin/Addons/checkForm', '检测创建', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('44', 'admin', '1', 'Admin/Addons/preview', '预览', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('45', 'admin', '1', 'Admin/Addons/build', '快速生成插件', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('46', 'admin', '1', 'Admin/Addons/config', '设置', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('47', 'admin', '1', 'Admin/Addons/disable', '禁用', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('48', 'admin', '1', 'Admin/Addons/enable', '启用', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('49', 'admin', '1', 'Admin/Addons/install', '安装', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('50', 'admin', '1', 'Admin/Addons/uninstall', '卸载', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('51', 'admin', '1', 'Admin/Addons/saveconfig', '更新配置', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('52', 'admin', '1', 'Admin/Addons/adminList', '插件后台列表', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('53', 'admin', '1', 'Admin/Addons/execute', 'URL方式访问插件', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('54', 'admin', '1', 'Admin/Addons/index', '插件管理', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('55', 'admin', '1', 'Admin/Addons/hooks', '钩子管理', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('56', 'admin', '1', 'Admin/model/add', '新增', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('57', 'admin', '1', 'Admin/model/edit', '编辑', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('58', 'admin', '1', 'Admin/model/setStatus', '改变状态', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('59', 'admin', '1', 'Admin/model/update', '保存数据', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('60', 'admin', '1', 'Admin/Model/index', '模型管理', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('61', 'admin', '1', 'Admin/Config/edit', '编辑', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('62', 'admin', '1', 'Admin/Config/del', '删除', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('63', 'admin', '1', 'Admin/Config/add', '新增', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('64', 'admin', '1', 'Admin/Config/save', '保存', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('65', 'admin', '1', 'Admin/Config/group', '网站设置', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('66', 'admin', '1', 'Admin/Config/index', '配置管理', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('67', 'admin', '1', 'Admin/Channel/add', '新增', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('68', 'admin', '1', 'Admin/Channel/edit', '编辑', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('69', 'admin', '1', 'Admin/Channel/del', '删除', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('70', 'admin', '1', 'Admin/Channel/index', '导航管理', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('71', 'admin', '1', 'Admin/Category/edit', '编辑', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('72', 'admin', '1', 'Admin/Category/add', '新增', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('73', 'admin', '1', 'Admin/Category/remove', '删除', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('74', 'admin', '1', 'Admin/Category/index', '分类管理', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('75', 'admin', '1', 'Admin/file/upload', '上传控件', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('76', 'admin', '1', 'Admin/file/uploadPicture', '上传图片', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('77', 'admin', '1', 'Admin/file/download', '下载', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('94', 'admin', '1', 'Admin/AuthManager/modelauth', '模型授权', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('79', 'admin', '1', 'Admin/article/batchOperate', '导入', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('80', 'admin', '1', 'Admin/Database/index?type=export', '备份数据库', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('81', 'admin', '1', 'Admin/Database/index?type=import', '还原数据库', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('82', 'admin', '1', 'Admin/Database/export', '备份', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('83', 'admin', '1', 'Admin/Database/optimize', '优化表', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('84', 'admin', '1', 'Admin/Database/repair', '修复表', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('86', 'admin', '1', 'Admin/Database/import', '恢复', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('87', 'admin', '1', 'Admin/Database/del', '删除', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('88', 'admin', '1', 'Admin/User/add', '新增用户', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('89', 'admin', '1', 'Admin/Attribute/index', '属性管理', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('90', 'admin', '1', 'Admin/Attribute/add', '新增', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('91', 'admin', '1', 'Admin/Attribute/edit', '编辑', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('92', 'admin', '1', 'Admin/Attribute/setStatus', '改变状态', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('93', 'admin', '1', 'Admin/Attribute/update', '保存数据', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('95', 'admin', '1', 'Admin/AuthManager/addToModel', '保存模型授权', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('96', 'admin', '1', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('97', 'admin', '1', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('98', 'admin', '1', 'Admin/Config/menu', '后台菜单管理', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('99', 'admin', '1', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('100', 'admin', '1', 'Admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('101', 'admin', '1', 'Admin/other', '其他', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('102', 'admin', '1', 'Admin/Menu/add', '新增', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('103', 'admin', '1', 'Admin/Menu/edit', '编辑', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('104', 'admin', '1', 'Admin/Think/lists?model=article', '文章管理', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('105', 'admin', '1', 'Admin/Think/lists?model=download', '下载管理', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('106', 'admin', '1', 'Admin/Think/lists?model=config', '配置管理', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('107', 'admin', '1', 'Admin/Action/actionlog', '行为日志', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('108', 'admin', '1', 'Admin/User/updatePassword', '修改密码', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('109', 'admin', '1', 'Admin/User/updateNickname', '修改昵称', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('110', 'admin', '1', 'Admin/action/edit', '查看行为日志', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('205', 'admin', '1', 'Admin/think/add', '新增数据', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('111', 'admin', '2', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('112', 'admin', '2', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('113', 'admin', '2', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('114', 'admin', '2', 'Admin/article/setStatus', '改变状态', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('115', 'admin', '2', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('116', 'admin', '2', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('117', 'admin', '2', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('118', 'admin', '2', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('119', 'admin', '2', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('120', 'admin', '2', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('121', 'admin', '2', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('122', 'admin', '2', 'Admin/article/permit', '还原', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('123', 'admin', '2', 'Admin/article/clear', '清空', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('124', 'admin', '2', 'Admin/User/add', '新增用户', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('125', 'admin', '2', 'Admin/User/action', '用户行为', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('126', 'admin', '2', 'Admin/User/addAction', '新增用户行为', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('127', 'admin', '2', 'Admin/User/editAction', '编辑用户行为', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('128', 'admin', '2', 'Admin/User/saveAction', '保存用户行为', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('129', 'admin', '2', 'Admin/User/setStatus', '变更行为状态', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('130', 'admin', '2', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('131', 'admin', '2', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('132', 'admin', '2', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('133', 'admin', '2', 'Admin/AuthManager/index', '权限管理', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('134', 'admin', '2', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('135', 'admin', '2', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('136', 'admin', '2', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('137', 'admin', '2', 'Admin/AuthManager/createGroup', '新增', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('138', 'admin', '2', 'Admin/AuthManager/editGroup', '编辑', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('139', 'admin', '2', 'Admin/AuthManager/writeGroup', '保存用户组', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('140', 'admin', '2', 'Admin/AuthManager/group', '授权', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('141', 'admin', '2', 'Admin/AuthManager/access', '访问授权', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('142', 'admin', '2', 'Admin/AuthManager/user', '成员授权', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('143', 'admin', '2', 'Admin/AuthManager/removeFromGroup', '解除授权', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('144', 'admin', '2', 'Admin/AuthManager/addToGroup', '保存成员授权', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('145', 'admin', '2', 'Admin/AuthManager/category', '分类授权', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('146', 'admin', '2', 'Admin/AuthManager/addToCategory', '保存分类授权', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('147', 'admin', '2', 'Admin/AuthManager/modelauth', '模型授权', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('148', 'admin', '2', 'Admin/AuthManager/addToModel', '保存模型授权', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('149', 'admin', '2', 'Admin/Addons/create', '创建', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('150', 'admin', '2', 'Admin/Addons/checkForm', '检测创建', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('151', 'admin', '2', 'Admin/Addons/preview', '预览', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('152', 'admin', '2', 'Admin/Addons/build', '快速生成插件', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('153', 'admin', '2', 'Admin/Addons/config', '设置', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('154', 'admin', '2', 'Admin/Addons/disable', '禁用', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('155', 'admin', '2', 'Admin/Addons/enable', '启用', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('156', 'admin', '2', 'Admin/Addons/install', '安装', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('157', 'admin', '2', 'Admin/Addons/uninstall', '卸载', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('158', 'admin', '2', 'Admin/Addons/saveconfig', '更新配置', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('159', 'admin', '2', 'Admin/Addons/adminList', '插件后台列表', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('160', 'admin', '2', 'Admin/Addons/execute', 'URL方式访问插件', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('161', 'admin', '2', 'Admin/Addons/hooks', '钩子管理', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('162', 'admin', '2', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('163', 'admin', '2', 'Admin/model/add', '新增', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('164', 'admin', '2', 'Admin/model/edit', '编辑', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('165', 'admin', '2', 'Admin/model/setStatus', '改变状态', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('166', 'admin', '2', 'Admin/model/update', '保存数据', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('167', 'admin', '2', 'Admin/Attribute/index', '属性管理', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('168', 'admin', '2', 'Admin/Attribute/add', '新增', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('169', 'admin', '2', 'Admin/Attribute/edit', '编辑', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('170', 'admin', '2', 'Admin/Attribute/setStatus', '改变状态', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('171', 'admin', '2', 'Admin/Attribute/update', '保存数据', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('172', 'admin', '2', 'Admin/Config/index', '配置管理', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('173', 'admin', '2', 'Admin/Config/edit', '编辑', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('174', 'admin', '2', 'Admin/Config/del', '删除', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('175', 'admin', '2', 'Admin/Config/add', '新增', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('176', 'admin', '2', 'Admin/Config/save', '保存', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('177', 'admin', '2', 'Admin/Menu/index', '菜单管理', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('178', 'admin', '2', 'Admin/Channel/index', '导航管理', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('179', 'admin', '2', 'Admin/Channel/add', '新增', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('180', 'admin', '2', 'Admin/Channel/edit', '编辑', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('181', 'admin', '2', 'Admin/Channel/del', '删除', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('182', 'admin', '2', 'Admin/Category/index', '分类管理', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('183', 'admin', '2', 'Admin/Category/edit', '编辑', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('184', 'admin', '2', 'Admin/Category/add', '新增', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('185', 'admin', '2', 'Admin/Category/remove', '删除', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('186', 'admin', '2', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('187', 'admin', '2', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('188', 'admin', '2', 'Admin/Database/index?type=export', '备份数据库', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('189', 'admin', '2', 'Admin/Database/export', '备份', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('190', 'admin', '2', 'Admin/Database/optimize', '优化表', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('191', 'admin', '2', 'Admin/Database/repair', '修复表', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('192', 'admin', '2', 'Admin/Database/index?type=import', '还原数据库', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('193', 'admin', '2', 'Admin/Database/import', '恢复', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('194', 'admin', '2', 'Admin/Database/del', '删除', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('195', 'admin', '2', 'Admin/other', '其他', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('196', 'admin', '2', 'Admin/Menu/add', '新增', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('197', 'admin', '2', 'Admin/Menu/edit', '编辑', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('198', 'admin', '2', 'Admin/Think/lists?model=article', '应用', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('199', 'admin', '2', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('200', 'admin', '2', 'Admin/Think/lists?model=config', '应用', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('201', 'admin', '2', 'Admin/Action/actionlog', '行为日志', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('202', 'admin', '2', 'Admin/User/updatePassword', '修改密码', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('203', 'admin', '2', 'Admin/User/updateNickname', '修改昵称', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('204', 'admin', '2', 'Admin/action/edit', '查看行为日志', '-1', '');
INSERT INTO `ot_auth_rule` VALUES ('206', 'admin', '1', 'Admin/think/edit', '编辑数据', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('207', 'admin', '1', 'Admin/Menu/import', '导入', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('208', 'admin', '1', 'Admin/Model/generate', '生成', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('209', 'admin', '1', 'Admin/Addons/addHook', '新增钩子', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('210', 'admin', '1', 'Admin/Addons/edithook', '编辑钩子', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('211', 'admin', '1', 'Admin/Article/sort', '文档排序', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('212', 'admin', '1', 'Admin/Config/sort', '排序', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('213', 'admin', '1', 'Admin/Menu/sort', '排序', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('214', 'admin', '1', 'Admin/Channel/sort', '排序', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('215', 'admin', '1', 'Admin/Category/operate/type/move', '移动', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('216', 'admin', '1', 'Admin/Category/operate/type/merge', '合并', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('217', 'admin', '1', 'Admin/LuStrategy/edit', '编辑', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('218', 'admin', '1', 'Admin/LuStrategy/add', '新增', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('219', 'admin', '1', 'Admin/LuStrategy/index', '策略列表', '1', '');
INSERT INTO `ot_auth_rule` VALUES ('220', 'admin', '2', 'Admin/LuStrategy/index', '策略', '1', '');

-- -----------------------------
-- Table structure for `ot_category`
-- -----------------------------
DROP TABLE IF EXISTS `ot_category`;
CREATE TABLE `ot_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '关联模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text NOT NULL COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `ot_category`
-- -----------------------------
INSERT INTO `ot_category` VALUES ('1', 'blog', '博客', '0', '0', '10', '', '', '', '', '', '', '', '2', '2,1', '0', '0', '1', '0', '0', '1', '', '1379474947', '1382701539', '1', '0');
INSERT INTO `ot_category` VALUES ('2', 'default_blog', '默认分类', '1', '1', '10', '', '', '', '', '', '', '', '2', '2,1,3', '0', '1', '1', '0', '1', '1', '', '1379475028', '1386839751', '1', '31');

-- -----------------------------
-- Table structure for `ot_channel`
-- -----------------------------
DROP TABLE IF EXISTS `ot_channel`;
CREATE TABLE `ot_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '频道ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级频道ID',
  `title` char(30) NOT NULL COMMENT '频道标题',
  `url` char(100) NOT NULL COMMENT '频道连接',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '导航排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `target` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '新窗口打开',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ot_channel`
-- -----------------------------
INSERT INTO `ot_channel` VALUES ('1', '0', '首页', 'Index/index', '1', '1379475111', '1379923177', '1', '0');
INSERT INTO `ot_channel` VALUES ('2', '0', '博客', 'Article/index?category=blog', '2', '1379475131', '1379483713', '1', '0');
INSERT INTO `ot_channel` VALUES ('3', '0', '官网', 'http://www.onethink.cn', '3', '1379475154', '1387163458', '1', '0');

-- -----------------------------
-- Table structure for `ot_config`
-- -----------------------------
DROP TABLE IF EXISTS `ot_config`;
CREATE TABLE `ot_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ot_config`
-- -----------------------------
INSERT INTO `ot_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1379235274', '1', 'LuSmartStock管理', '0');
INSERT INTO `ot_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', 'LuSmartStock管理', '1');
INSERT INTO `ot_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', '', '8');
INSERT INTO `ot_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '1');
INSERT INTO `ot_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '2');
INSERT INTO `ot_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '', '9');
INSERT INTO `ot_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐位', '2', '', '文档推荐位，推荐到多个位置KEY值相加即可', '1379053380', '1379235329', '1', '1:列表页推荐\r\n2:频道页推荐\r\n4:网站首页推荐', '3');
INSERT INTO `ot_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见性', '2', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1379235322', '1', '0:所有人可见\r\n1:仅注册会员可见\r\n2:仅管理员可见', '4');
INSERT INTO `ot_config` VALUES ('13', 'COLOR_STYLE', '4', '后台色系', '1', 'default_color:默认\r\nblue_color:紫罗兰', '后台颜色风格', '1379122533', '1379235904', '1', 'default_color', '10');
INSERT INTO `ot_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1384418383', '1', '1:基本\r\n2:内容\r\n3:用户\r\n4:系统', '4');
INSERT INTO `ot_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '6');
INSERT INTO `ot_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '8');
INSERT INTO `ot_config` VALUES ('23', 'OPEN_DRAFTBOX', '4', '是否开启草稿功能', '2', '0:关闭草稿功能\r\n1:开启草稿功能\r\n', '新增文章时的草稿功能配置', '1379484332', '1379484591', '1', '1', '1');
INSERT INTO `ot_config` VALUES ('24', 'DRAFT_AOTOSAVE_INTERVAL', '0', '自动保存草稿时间', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1386143323', '1', '60', '2');
INSERT INTO `ot_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录数', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '10', '10');
INSERT INTO `ot_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '3');
INSERT INTO `ot_config` VALUES ('27', 'CODEMIRROR_THEME', '4', '预览插件的CodeMirror主题', '4', '3024-day:3024 day\r\n3024-night:3024 night\r\nambiance:ambiance\r\nbase16-dark:base16 dark\r\nbase16-light:base16 light\r\nblackboard:blackboard\r\ncobalt:cobalt\r\neclipse:eclipse\r\nelegant:elegant\r\nerlang-dark:erlang-dark\r\nlesser-dark:lesser-dark\r\nmidnight:midnight', '详情见CodeMirror官网', '1379814385', '1384740813', '1', 'ambiance', '3');
INSERT INTO `ot_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '5');
INSERT INTO `ot_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '7');
INSERT INTO `ot_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '9');
INSERT INTO `ot_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '10');
INSERT INTO `ot_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '11');
INSERT INTO `ot_config` VALUES ('33', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '', '1386644047', '1386644741', '1', '0:article/draftbox\r\n1:article/mydocument\r\n2:Category/tree\r\n3:Index/verify\r\n4:file/upload\r\n5:file/download\r\n6:user/updatePassword\r\n7:user/updateNickname\r\n8:user/submitPassword\r\n9:user/submitNickname\r\n10:file/uploadpicture', '0');
INSERT INTO `ot_config` VALUES ('34', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '', '仅超级管理员可访问的控制器方法', '1386644141', '1386644659', '1', '0:Addons/addhook\r\n1:Addons/edithook\r\n2:Addons/delhook\r\n3:Addons/updateHook\r\n4:Admin/getMenus\r\n5:Admin/recordList\r\n6:AuthManager/updateRules\r\n7:AuthManager/tree', '0');
INSERT INTO `ot_config` VALUES ('35', 'REPLY_LIST_ROWS', '0', '回复列表每页条数', '2', '', '', '1386645376', '1387178083', '1', '10', '0');
INSERT INTO `ot_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '12');
INSERT INTO `ot_config` VALUES ('37', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '4', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '0', '1');

-- -----------------------------
-- Table structure for `ot_document`
-- -----------------------------
DROP TABLE IF EXISTS `ot_document`;
CREATE TABLE `ot_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '标题',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `description` char(140) NOT NULL DEFAULT '' COMMENT '描述',
  `root` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '根节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属ID',
  `model_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容模型ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '可见性',
  `deadline` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '截至时间',
  `attach` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `comment` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扩展统计字段',
  `level` int(10) NOT NULL DEFAULT '0' COMMENT '优先级',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  PRIMARY KEY (`id`),
  KEY `idx_category_status` (`category_id`,`status`),
  KEY `idx_status_type_pid` (`status`,`uid`,`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='文档模型基础表';

-- -----------------------------
-- Records of `ot_document`
-- -----------------------------
INSERT INTO `ot_document` VALUES ('1', '1', '', 'OneThink1.0正式版发布', '2', '大家期待的OneThink正式版发布', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '8', '0', '0', '0', '1387260660', '1387263112', '1');

-- -----------------------------
-- Table structure for `ot_document_article`
-- -----------------------------
DROP TABLE IF EXISTS `ot_document_article`;
CREATE TABLE `ot_document_article` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '文章内容',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `bookmark` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型文章表';

-- -----------------------------
-- Records of `ot_document_article`
-- -----------------------------
INSERT INTO `ot_document_article` VALUES ('1', '0', '<h1>\r\n	OneThink1.0正式版发布&nbsp;\r\n</h1>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>OneThink是一个开源的内容管理框架，基于最新的ThinkPHP3.2版本开发，提供更方便、更安全的WEB应用开发体验，采用了全新的架构设计和命名空间机制，融合了模块化、驱动化和插件化的设计理念于一体，开启了国内WEB应用傻瓜式开发的新潮流。&nbsp;</strong> \r\n</p>\r\n<h2>\r\n	主要特性：\r\n</h2>\r\n<p>\r\n	1. 基于ThinkPHP最新3.2版本。\r\n</p>\r\n<p>\r\n	2. 模块化：全新的架构和模块化的开发机制，便于灵活扩展和二次开发。&nbsp;\r\n</p>\r\n<p>\r\n	3. 文档模型/分类体系：通过和文档模型绑定，以及不同的文档类型，不同分类可以实现差异化的功能，轻松实现诸如资讯、下载、讨论和图片等功能。\r\n</p>\r\n<p>\r\n	4. 开源免费：OneThink遵循Apache2开源协议,免费提供使用。&nbsp;\r\n</p>\r\n<p>\r\n	5. 用户行为：支持自定义用户行为，可以对单个用户或者群体用户的行为进行记录及分享，为您的运营决策提供有效参考数据。\r\n</p>\r\n<p>\r\n	6. 云端部署：通过驱动的方式可以轻松支持平台的部署，让您的网站无缝迁移，内置已经支持SAE和BAE3.0。\r\n</p>\r\n<p>\r\n	7. 云服务支持：即将启动支持云存储、云安全、云过滤和云统计等服务，更多贴心的服务让您的网站更安心。\r\n</p>\r\n<p>\r\n	8. 安全稳健：提供稳健的安全策略，包括备份恢复、容错、防止恶意攻击登录，网页防篡改等多项安全管理功能，保证系统安全，可靠、稳定的运行。&nbsp;\r\n</p>\r\n<p>\r\n	9. 应用仓库：官方应用仓库拥有大量来自第三方插件和应用模块、模板主题，有众多来自开源社区的贡献，让您的网站“One”美无缺。&nbsp;\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>&nbsp;OneThink集成了一个完善的后台管理体系和前台模板标签系统，让你轻松管理数据和进行前台网站的标签式开发。&nbsp;</strong> \r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<h2>\r\n	后台主要功能：\r\n</h2>\r\n<p>\r\n	1. 用户Passport系统\r\n</p>\r\n<p>\r\n	2. 配置管理系统&nbsp;\r\n</p>\r\n<p>\r\n	3. 权限控制系统\r\n</p>\r\n<p>\r\n	4. 后台建模系统&nbsp;\r\n</p>\r\n<p>\r\n	5. 多级分类系统&nbsp;\r\n</p>\r\n<p>\r\n	6. 用户行为系统&nbsp;\r\n</p>\r\n<p>\r\n	7. 钩子和插件系统\r\n</p>\r\n<p>\r\n	8. 系统日志系统&nbsp;\r\n</p>\r\n<p>\r\n	9. 数据备份和还原\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	&nbsp;[ 官方下载：&nbsp;<a href=\"http://www.onethink.cn/download.html\" target=\"_blank\">http://www.onethink.cn/download.html</a>&nbsp;&nbsp;开发手册：<a href=\"http://document.onethink.cn/\" target=\"_blank\">http://document.onethink.cn/</a>&nbsp;]&nbsp;\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>OneThink开发团队 2013</strong> \r\n</p>', '', '0');

-- -----------------------------
-- Table structure for `ot_document_download`
-- -----------------------------
DROP TABLE IF EXISTS `ot_document_download`;
CREATE TABLE `ot_document_download` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '下载详细描述',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型下载表';


-- -----------------------------
-- Table structure for `ot_file`
-- -----------------------------
DROP TABLE IF EXISTS `ot_file`;
CREATE TABLE `ot_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件表';


-- -----------------------------
-- Table structure for `ot_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `ot_hooks`;
CREATE TABLE `ot_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text NOT NULL COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ot_hooks`
-- -----------------------------
INSERT INTO `ot_hooks` VALUES ('1', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '0', '');
INSERT INTO `ot_hooks` VALUES ('2', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '0', 'ReturnTop');
INSERT INTO `ot_hooks` VALUES ('3', 'documentEditForm', '添加编辑表单的 扩展内容钩子', '1', '0', 'Attachment');
INSERT INTO `ot_hooks` VALUES ('4', 'documentDetailAfter', '文档末尾显示', '1', '0', 'Attachment,SocialComment');
INSERT INTO `ot_hooks` VALUES ('5', 'documentDetailBefore', '页面内容前显示用钩子', '1', '0', '');
INSERT INTO `ot_hooks` VALUES ('6', 'documentSaveComplete', '保存文档数据后的扩展钩子', '2', '0', 'Attachment');
INSERT INTO `ot_hooks` VALUES ('7', 'documentEditFormContent', '添加编辑表单的内容显示钩子', '1', '0', 'Editor');
INSERT INTO `ot_hooks` VALUES ('8', 'adminArticleEdit', '后台内容编辑页编辑器', '1', '1378982734', 'EditorForAdmin');
INSERT INTO `ot_hooks` VALUES ('13', 'AdminIndex', '首页小格子个性化显示', '1', '1382596073', 'SiteStat,SystemInfo,DevTeam');
INSERT INTO `ot_hooks` VALUES ('14', 'topicComment', '评论提交方式扩展钩子。', '1', '1380163518', 'Editor');
INSERT INTO `ot_hooks` VALUES ('16', 'app_begin', '应用开始', '2', '1384481614', '');

-- -----------------------------
-- Table structure for `ot_member`
-- -----------------------------
DROP TABLE IF EXISTS `ot_member`;
CREATE TABLE `ot_member` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` char(16) NOT NULL DEFAULT '' COMMENT '昵称',
  `sex` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date NOT NULL DEFAULT '0000-00-00' COMMENT '生日',
  `qq` char(10) NOT NULL DEFAULT '' COMMENT 'qq号',
  `score` mediumint(8) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `login` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '会员状态',
  PRIMARY KEY (`uid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `ot_member`
-- -----------------------------
INSERT INTO `ot_member` VALUES ('1', 'admin', '0', '0000-00-00', '', '40', '10', '0', '1480060840', '2130706433', '1480908056', '1');

-- -----------------------------
-- Table structure for `ot_menu`
-- -----------------------------
DROP TABLE IF EXISTS `ot_menu`;
CREATE TABLE `ot_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=126 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ot_menu`
-- -----------------------------
INSERT INTO `ot_menu` VALUES ('1', '首页', '0', '1', 'Index/index', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('2', '内容', '0', '2', 'Article/mydocument', '1', '', '', '1');
INSERT INTO `ot_menu` VALUES ('3', '文档列表', '2', '0', 'article/index', '1', '', '内容', '0');
INSERT INTO `ot_menu` VALUES ('4', '新增', '3', '0', 'article/add', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('5', '编辑', '3', '0', 'article/edit', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('6', '改变状态', '3', '0', 'article/setStatus', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('7', '保存', '3', '0', 'article/update', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('8', '保存草稿', '3', '0', 'article/autoSave', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('9', '移动', '3', '0', 'article/move', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('10', '复制', '3', '0', 'article/copy', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('11', '粘贴', '3', '0', 'article/paste', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('12', '导入', '3', '0', 'article/batchOperate', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('13', '回收站', '2', '0', 'article/recycle', '1', '', '内容', '0');
INSERT INTO `ot_menu` VALUES ('14', '还原', '13', '0', 'article/permit', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('15', '清空', '13', '0', 'article/clear', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('16', '用户', '0', '3', 'User/index', '1', '', '', '0');
INSERT INTO `ot_menu` VALUES ('17', '用户信息', '16', '0', 'User/index', '0', '', '用户管理', '0');
INSERT INTO `ot_menu` VALUES ('18', '新增用户', '17', '0', 'User/add', '0', '添加新用户', '', '0');
INSERT INTO `ot_menu` VALUES ('19', '用户行为', '16', '0', 'User/action', '0', '', '行为管理', '0');
INSERT INTO `ot_menu` VALUES ('20', '新增用户行为', '19', '0', 'User/addaction', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('21', '编辑用户行为', '19', '0', 'User/editaction', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('22', '保存用户行为', '19', '0', 'User/saveAction', '0', '\"用户->用户行为\"保存编辑和新增的用户行为', '', '0');
INSERT INTO `ot_menu` VALUES ('23', '变更行为状态', '19', '0', 'User/setStatus', '0', '\"用户->用户行为\"中的启用,禁用和删除权限', '', '0');
INSERT INTO `ot_menu` VALUES ('24', '禁用会员', '19', '0', 'User/changeStatus?method=forbidUser', '0', '\"用户->用户信息\"中的禁用', '', '0');
INSERT INTO `ot_menu` VALUES ('25', '启用会员', '19', '0', 'User/changeStatus?method=resumeUser', '0', '\"用户->用户信息\"中的启用', '', '0');
INSERT INTO `ot_menu` VALUES ('26', '删除会员', '19', '0', 'User/changeStatus?method=deleteUser', '0', '\"用户->用户信息\"中的删除', '', '0');
INSERT INTO `ot_menu` VALUES ('27', '权限管理', '16', '0', 'AuthManager/index', '0', '', '用户管理', '0');
INSERT INTO `ot_menu` VALUES ('28', '删除', '27', '0', 'AuthManager/changeStatus?method=deleteGroup', '0', '删除用户组', '', '0');
INSERT INTO `ot_menu` VALUES ('29', '禁用', '27', '0', 'AuthManager/changeStatus?method=forbidGroup', '0', '禁用用户组', '', '0');
INSERT INTO `ot_menu` VALUES ('30', '恢复', '27', '0', 'AuthManager/changeStatus?method=resumeGroup', '0', '恢复已禁用的用户组', '', '0');
INSERT INTO `ot_menu` VALUES ('31', '新增', '27', '0', 'AuthManager/createGroup', '0', '创建新的用户组', '', '0');
INSERT INTO `ot_menu` VALUES ('32', '编辑', '27', '0', 'AuthManager/editGroup', '0', '编辑用户组名称和描述', '', '0');
INSERT INTO `ot_menu` VALUES ('33', '保存用户组', '27', '0', 'AuthManager/writeGroup', '0', '新增和编辑用户组的\"保存\"按钮', '', '0');
INSERT INTO `ot_menu` VALUES ('34', '授权', '27', '0', 'AuthManager/group', '0', '\"后台 \\ 用户 \\ 用户信息\"列表页的\"授权\"操作按钮,用于设置用户所属用户组', '', '0');
INSERT INTO `ot_menu` VALUES ('35', '访问授权', '27', '0', 'AuthManager/access', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"访问授权\"操作按钮', '', '0');
INSERT INTO `ot_menu` VALUES ('36', '成员授权', '27', '0', 'AuthManager/user', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"成员授权\"操作按钮', '', '0');
INSERT INTO `ot_menu` VALUES ('37', '解除授权', '27', '0', 'AuthManager/removeFromGroup', '0', '\"成员授权\"列表页内的解除授权操作按钮', '', '0');
INSERT INTO `ot_menu` VALUES ('38', '保存成员授权', '27', '0', 'AuthManager/addToGroup', '0', '\"用户信息\"列表页\"授权\"时的\"保存\"按钮和\"成员授权\"里右上角的\"添加\"按钮)', '', '0');
INSERT INTO `ot_menu` VALUES ('39', '分类授权', '27', '0', 'AuthManager/category', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"分类授权\"操作按钮', '', '0');
INSERT INTO `ot_menu` VALUES ('40', '保存分类授权', '27', '0', 'AuthManager/addToCategory', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0');
INSERT INTO `ot_menu` VALUES ('41', '模型授权', '27', '0', 'AuthManager/modelauth', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"模型授权\"操作按钮', '', '0');
INSERT INTO `ot_menu` VALUES ('42', '保存模型授权', '27', '0', 'AuthManager/addToModel', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0');
INSERT INTO `ot_menu` VALUES ('43', '扩展', '0', '7', 'Addons/index', '1', '', '', '0');
INSERT INTO `ot_menu` VALUES ('44', '插件管理', '43', '1', 'Addons/index', '0', '', '扩展', '0');
INSERT INTO `ot_menu` VALUES ('45', '创建', '44', '0', 'Addons/create', '0', '服务器上创建插件结构向导', '', '0');
INSERT INTO `ot_menu` VALUES ('46', '检测创建', '44', '0', 'Addons/checkForm', '0', '检测插件是否可以创建', '', '0');
INSERT INTO `ot_menu` VALUES ('47', '预览', '44', '0', 'Addons/preview', '0', '预览插件定义类文件', '', '0');
INSERT INTO `ot_menu` VALUES ('48', '快速生成插件', '44', '0', 'Addons/build', '0', '开始生成插件结构', '', '0');
INSERT INTO `ot_menu` VALUES ('49', '设置', '44', '0', 'Addons/config', '0', '设置插件配置', '', '0');
INSERT INTO `ot_menu` VALUES ('50', '禁用', '44', '0', 'Addons/disable', '0', '禁用插件', '', '0');
INSERT INTO `ot_menu` VALUES ('51', '启用', '44', '0', 'Addons/enable', '0', '启用插件', '', '0');
INSERT INTO `ot_menu` VALUES ('52', '安装', '44', '0', 'Addons/install', '0', '安装插件', '', '0');
INSERT INTO `ot_menu` VALUES ('53', '卸载', '44', '0', 'Addons/uninstall', '0', '卸载插件', '', '0');
INSERT INTO `ot_menu` VALUES ('54', '更新配置', '44', '0', 'Addons/saveconfig', '0', '更新插件配置处理', '', '0');
INSERT INTO `ot_menu` VALUES ('55', '插件后台列表', '44', '0', 'Addons/adminList', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('56', 'URL方式访问插件', '44', '0', 'Addons/execute', '0', '控制是否有权限通过url访问插件控制器方法', '', '0');
INSERT INTO `ot_menu` VALUES ('57', '钩子管理', '43', '2', 'Addons/hooks', '0', '', '扩展', '0');
INSERT INTO `ot_menu` VALUES ('58', '模型管理', '68', '3', 'Model/index', '1', '', '系统设置', '0');
INSERT INTO `ot_menu` VALUES ('59', '新增', '58', '0', 'model/add', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('60', '编辑', '58', '0', 'model/edit', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('61', '改变状态', '58', '0', 'model/setStatus', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('62', '保存数据', '58', '0', 'model/update', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('63', '属性管理', '68', '0', 'Attribute/index', '1', '网站属性配置。', '', '0');
INSERT INTO `ot_menu` VALUES ('64', '新增', '63', '0', 'Attribute/add', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('65', '编辑', '63', '0', 'Attribute/edit', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('66', '改变状态', '63', '0', 'Attribute/setStatus', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('67', '保存数据', '63', '0', 'Attribute/update', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('68', '数据备份', '0', '4', 'Database/index?type=export', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('69', '网站设置', '68', '1', 'Config/group', '1', '', '系统设置', '0');
INSERT INTO `ot_menu` VALUES ('70', '配置管理', '68', '4', 'Config/index', '1', '', '系统设置', '0');
INSERT INTO `ot_menu` VALUES ('71', '编辑', '70', '0', 'Config/edit', '0', '新增编辑和保存配置', '', '0');
INSERT INTO `ot_menu` VALUES ('72', '删除', '70', '0', 'Config/del', '0', '删除配置', '', '0');
INSERT INTO `ot_menu` VALUES ('73', '新增', '70', '0', 'Config/add', '0', '新增配置', '', '0');
INSERT INTO `ot_menu` VALUES ('74', '保存', '70', '0', 'Config/save', '0', '保存配置', '', '0');
INSERT INTO `ot_menu` VALUES ('75', '菜单管理', '68', '5', 'Menu/index', '1', '', '系统设置', '0');
INSERT INTO `ot_menu` VALUES ('76', '导航管理', '68', '6', 'Channel/index', '1', '', '系统设置', '0');
INSERT INTO `ot_menu` VALUES ('77', '新增', '76', '0', 'Channel/add', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('78', '编辑', '76', '0', 'Channel/edit', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('79', '删除', '76', '0', 'Channel/del', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('80', '分类管理', '68', '2', 'Category/index', '1', '', '系统设置', '0');
INSERT INTO `ot_menu` VALUES ('81', '编辑', '80', '0', 'Category/edit', '0', '编辑和保存栏目分类', '', '0');
INSERT INTO `ot_menu` VALUES ('82', '新增', '80', '0', 'Category/add', '0', '新增栏目分类', '', '0');
INSERT INTO `ot_menu` VALUES ('83', '删除', '80', '0', 'Category/remove', '0', '删除栏目分类', '', '0');
INSERT INTO `ot_menu` VALUES ('84', '移动', '80', '0', 'Category/operate/type/move', '0', '移动栏目分类', '', '0');
INSERT INTO `ot_menu` VALUES ('85', '合并', '80', '0', 'Category/operate/type/merge', '0', '合并栏目分类', '', '0');
INSERT INTO `ot_menu` VALUES ('86', '备份数据库', '68', '0', 'Database/index?type=export', '0', '', '数据备份', '0');
INSERT INTO `ot_menu` VALUES ('87', '备份', '86', '0', 'Database/export', '0', '备份数据库', '', '0');
INSERT INTO `ot_menu` VALUES ('88', '优化表', '86', '0', 'Database/optimize', '0', '优化数据表', '', '0');
INSERT INTO `ot_menu` VALUES ('89', '修复表', '86', '0', 'Database/repair', '0', '修复数据表', '', '0');
INSERT INTO `ot_menu` VALUES ('90', '还原数据库', '68', '0', 'Database/index?type=import', '0', '', '数据备份', '0');
INSERT INTO `ot_menu` VALUES ('91', '恢复', '90', '0', 'Database/import', '0', '数据库恢复', '', '0');
INSERT INTO `ot_menu` VALUES ('92', '删除', '90', '0', 'Database/del', '0', '删除备份文件', '', '0');
INSERT INTO `ot_menu` VALUES ('93', '其他', '0', '5', 'other', '1', '', '', '0');
INSERT INTO `ot_menu` VALUES ('96', '新增', '75', '0', 'Menu/add', '1', '', '系统设置', '0');
INSERT INTO `ot_menu` VALUES ('98', '编辑', '75', '0', 'Menu/edit', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('104', '下载管理', '102', '0', 'Think/lists?model=download', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('105', '配置管理', '102', '0', 'Think/lists?model=config', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('106', '行为日志', '16', '0', 'Action/actionlog', '0', '', '行为管理', '0');
INSERT INTO `ot_menu` VALUES ('108', '修改密码', '16', '0', 'User/updatePassword', '1', '', '', '0');
INSERT INTO `ot_menu` VALUES ('109', '修改昵称', '16', '0', 'User/updateNickname', '1', '', '', '0');
INSERT INTO `ot_menu` VALUES ('110', '查看行为日志', '106', '0', 'action/edit', '1', '', '', '0');
INSERT INTO `ot_menu` VALUES ('112', '新增数据', '58', '0', 'think/add', '1', '', '', '0');
INSERT INTO `ot_menu` VALUES ('113', '编辑数据', '58', '0', 'think/edit', '1', '', '', '0');
INSERT INTO `ot_menu` VALUES ('114', '导入', '75', '0', 'Menu/import', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('115', '生成', '58', '0', 'Model/generate', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('116', '新增钩子', '57', '0', 'Addons/addHook', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('117', '编辑钩子', '57', '0', 'Addons/edithook', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('118', '文档排序', '3', '0', 'Article/sort', '1', '', '', '0');
INSERT INTO `ot_menu` VALUES ('119', '排序', '70', '0', 'Config/sort', '1', '', '', '0');
INSERT INTO `ot_menu` VALUES ('120', '排序', '75', '0', 'Menu/sort', '1', '', '', '0');
INSERT INTO `ot_menu` VALUES ('121', '排序', '76', '0', 'Channel/sort', '1', '', '', '0');
INSERT INTO `ot_menu` VALUES ('122', '策略', '0', '2', 'LuStrategy/index', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('123', '策略列表', '122', '1', 'LuStrategy/index', '0', '', '策略', '0');
INSERT INTO `ot_menu` VALUES ('124', '编辑', '123', '0', 'LuStrategy/edit', '0', '', '', '0');
INSERT INTO `ot_menu` VALUES ('125', '新增', '124', '0', 'LuStrategy/add', '0', '', '', '0');

-- -----------------------------
-- Table structure for `ot_model`
-- -----------------------------
DROP TABLE IF EXISTS `ot_model`;
CREATE TABLE `ot_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '继承的模型',
  `relation` varchar(30) NOT NULL DEFAULT '' COMMENT '继承与被继承模型的关联字段',
  `need_pk` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '新建表时是否需要主键字段',
  `field_sort` text NOT NULL COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text NOT NULL COMMENT '属性列表（表的字段）',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text NOT NULL COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `engine_type` varchar(25) NOT NULL DEFAULT 'MyISAM' COMMENT '数据库引擎',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `ot_model`
-- -----------------------------
INSERT INTO `ot_model` VALUES ('1', 'document', '基础文档', '0', '', '1', '{\"1\":[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\",\"9\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"22\"]}', '1:基础', '', '', '', '', 'id:编号\r\ntitle:标题:article/index?cate_id=[category_id]&pid=[id]\r\ntype|get_document_type:类型\r\nlevel:优先级\r\nupdate_time|time_format:最后更新\r\nstatus_text:状态\r\nview:浏览\r\nid:操作:[EDIT]&cate_id=[category_id]|编辑,article/setstatus?status=-1&ids=[id]|删除', '0', '', '', '1383891233', '1384507827', '1', 'MyISAM');
INSERT INTO `ot_model` VALUES ('2', 'article', '文章', '1', '', '1', '{\"1\":[\"3\",\"24\",\"2\",\"5\"],\"2\":[\"9\",\"13\",\"19\",\"10\",\"12\",\"16\",\"17\",\"26\",\"20\",\"14\",\"11\",\"25\"]}', '1:基础,2:扩展', '', '', '', '', 'id:编号\r\ntitle:标题:article/edit?cate_id=[category_id]&id=[id]\r\ncontent:内容', '0', '', '', '1383891243', '1387260622', '1', 'MyISAM');
INSERT INTO `ot_model` VALUES ('3', 'download', '下载', '1', '', '1', '{\"1\":[\"3\",\"28\",\"30\",\"32\",\"2\",\"5\",\"31\"],\"2\":[\"13\",\"10\",\"27\",\"9\",\"12\",\"16\",\"17\",\"19\",\"11\",\"20\",\"14\",\"29\"]}', '1:基础,2:扩展', '', '', '', '', 'id:编号\r\ntitle:标题', '0', '', '', '1383891252', '1387260449', '1', 'MyISAM');

-- -----------------------------
-- Table structure for `ot_picture`
-- -----------------------------
DROP TABLE IF EXISTS `ot_picture`;
CREATE TABLE `ot_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `ot_picture`
-- -----------------------------
INSERT INTO `ot_picture` VALUES ('1', '/Uploads/Picture/2016-11-29/583d26fc39a2d.jpg', '', '6bc0872ae912bbe2b890078908345040', 'd841c294d369d5d61088ce2704bf1fe62a20285c', '1', '1480402684');
INSERT INTO `ot_picture` VALUES ('2', '/Uploads/Picture/2016-11-30/583ea48a50e69.jpg', '', 'dedd18d98727aaa0666af7c8c5ee9c60', '9484eda4bef45ba5b76a6916581b2dbc0a6a6870', '1', '1480500362');
INSERT INTO `ot_picture` VALUES ('3', '/Uploads/Picture/2016-11-30/583eafbd95dbc.png', '', '3534ffca66809c0906df8adeb369dbde', 'a3412b5a65a59cb048f578ddaefa1cd0ccef69c2', '1', '1480503229');
INSERT INTO `ot_picture` VALUES ('4', '/Uploads/Picture/2016-12-01/583ff8a96d07d.jpg', '', '50cb78ad6cc22fb0fdb126d424000ea4', '7be7cad04c45b6acf2dd7ed44a69b0270864a76b', '1', '1480587433');
INSERT INTO `ot_picture` VALUES ('5', '/Uploads/Picture/2016-12-02/584154cd08764.jpg', '', 'f835e3ba29fde9c897a819735dd1bb21', 'ca6a27a39908c3441aa97d66a2afb4d302ec8737', '1', '1480676556');
INSERT INTO `ot_picture` VALUES ('6', '/Uploads/Picture/2016-12-02/584159959be75.jpg', '', 'cd6fd1d6f6cd2adcbf0a7f9aeba589f3', '71cf7f4c2e5ef624d64a430e7c2c467af754952e', '1', '1480677781');

-- -----------------------------
-- Table structure for `ot_ucenter_admin`
-- -----------------------------
DROP TABLE IF EXISTS `ot_ucenter_admin`;
CREATE TABLE `ot_ucenter_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员用户ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='管理员表';


-- -----------------------------
-- Table structure for `ot_ucenter_app`
-- -----------------------------
DROP TABLE IF EXISTS `ot_ucenter_app`;
CREATE TABLE `ot_ucenter_app` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '应用ID',
  `title` varchar(30) NOT NULL COMMENT '应用名称',
  `url` varchar(100) NOT NULL COMMENT '应用URL',
  `ip` char(15) NOT NULL COMMENT '应用IP',
  `auth_key` varchar(100) NOT NULL COMMENT '加密KEY',
  `sys_login` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '同步登陆',
  `allow_ip` varchar(255) NOT NULL COMMENT '允许访问的IP',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '应用状态',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='应用表';


-- -----------------------------
-- Table structure for `ot_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `ot_ucenter_member`;
CREATE TABLE `ot_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `ot_ucenter_member`
-- -----------------------------
INSERT INTO `ot_ucenter_member` VALUES ('1', 'admin', 'b8e5b58fef11fa68271bb0a8dc2e9e6d', '908581016@qq.com', '', '1480060840', '0', '1480908056', '2130706433', '1480060840', '1');

-- -----------------------------
-- Table structure for `ot_ucenter_setting`
-- -----------------------------
DROP TABLE IF EXISTS `ot_ucenter_setting`;
CREATE TABLE `ot_ucenter_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '设置ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型（1-用户配置）',
  `value` text NOT NULL COMMENT '配置数据',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='设置表';


-- -----------------------------
-- Table structure for `ot_url`
-- -----------------------------
DROP TABLE IF EXISTS `ot_url`;
CREATE TABLE `ot_url` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '链接唯一标识',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `short` char(100) NOT NULL DEFAULT '' COMMENT '短网址',
  `status` tinyint(2) NOT NULL DEFAULT '2' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='链接表';


-- -----------------------------
-- Table structure for `ot_userdata`
-- -----------------------------
DROP TABLE IF EXISTS `ot_userdata`;
CREATE TABLE `ot_userdata` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(3) unsigned NOT NULL COMMENT '类型标识',
  `target_id` int(10) unsigned NOT NULL COMMENT '目标id',
  UNIQUE KEY `uid` (`uid`,`type`,`target_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

